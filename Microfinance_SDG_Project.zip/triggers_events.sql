USE microfinance_sdg;
DELIMITER $$

-- Close a loan only when its full schedule exists and every installment is paid.
CREATE TRIGGER close_fully_paid_loan
AFTER UPDATE ON Repayments
FOR EACH ROW
BEGIN
    DECLARE unpaid_count INT;
    DECLARE schedule_count INT;
    DECLARE expected_count INT;
    IF NEW.status = 'paid' AND OLD.status <> 'paid' THEN
        SELECT COUNT(*), COUNT(CASE WHEN status <> 'paid' THEN 1 END)
        INTO schedule_count, unpaid_count FROM Repayments WHERE loan_id = NEW.loan_id;
        SELECT term_months INTO expected_count FROM Loans WHERE loan_id = NEW.loan_id;
        IF unpaid_count = 0 AND schedule_count = expected_count THEN
            UPDATE Loans SET status = 'closed' WHERE loan_id = NEW.loan_id AND status <> 'closed';
        END IF;
    END IF;
END$$

-- Save the old and new status in the same transaction as the status change.
CREATE TRIGGER record_loan_status
AFTER UPDATE ON Loans
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO LoanStatusLog (loan_id, old_status, new_status)
        VALUES (NEW.loan_id, OLD.status, NEW.status);
    END IF;
END$$
DELIMITER ;

-- Run at 00:05 each night in India time. A server administrator enables the scheduler.
SET time_zone = '+05:30';
CREATE EVENT nightly_penalty_update
ON SCHEDULE EVERY 1 DAY
STARTS TIMESTAMP(CURRENT_DATE + INTERVAL 1 DAY, '00:05:00')
DO CALL update_penalties();

-- Run separately as an administrator if the scheduler is OFF:
-- SET GLOBAL event_scheduler = ON;
-- SHOW VARIABLES LIKE 'event_scheduler';
