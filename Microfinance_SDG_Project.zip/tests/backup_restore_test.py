# Check the documented dump and restore commands on a disposable local server.
import argparse
from datetime import datetime
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

import mysql.connector


# Read from the source schema; restore only into a new, uniquely named schema.
parser = argparse.ArgumentParser()
parser.add_argument("--disposable-server", action="store_true", required=True)
parser.add_argument("--port", type=int, default=3307)
parser.add_argument("--database", required=True)
parser.add_argument("--user", default="root")
arguments = parser.parse_args()
if arguments.port == 3306:
    raise SystemExit("Use a separate disposable server, not port 3306.")
mysql_program = shutil.which("mysql")
dump_program = shutil.which("mysqldump")
if mysql_program is None or dump_program is None:
    raise SystemExit("Add the MySQL bin folder to PATH.")
password = os.environ.get("MYSQL_TEST_PASSWORD", "")
environment = os.environ.copy()
environment["MYSQL_PWD"] = password
restored_name = "microfinance_restore_" + datetime.now().strftime("%m%d%H%M%S")
connection = mysql.connector.connect(host="127.0.0.1", port=arguments.port,
                                     user=arguments.user, password=password, autocommit=True)
cursor = connection.cursor()
connection_options = ["--protocol=TCP", "--host=127.0.0.1", f"--port={arguments.port}", f"--user={arguments.user}"]

# Make a UTF-8 SQL backup without routing it through PowerShell's text encoding.
with tempfile.TemporaryDirectory(prefix="microfinance_backup_test_") as folder:
    backup_path = Path(folder) / "backup.sql"
    subprocess.run([dump_program] + connection_options + [
        "--single-transaction", "--routines", "--triggers", "--events", "--no-tablespaces",
        "--set-gtid-purged=OFF", "--databases", arguments.database, "--result-file=" + str(backup_path),
    ], env=environment, capture_output=True, text=True, check=True)

    # Change the database name in this test copy so the source cannot be overwritten.
    backup_text = backup_path.read_text(encoding="utf-8")
    backup_path.write_text(backup_text.replace(arguments.database, restored_name), encoding="utf-8")
    cursor.execute("SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME=%s", (restored_name,))
    assert cursor.fetchone()[0] == 0
    subprocess.run([mysql_program] + connection_options + ["--execute=SOURCE " + backup_path.as_posix()],
                   env=environment, capture_output=True, text=True, check=True)

# Compare every table, every view, and the counts of routines, triggers, and events.
cursor.execute("SELECT TABLE_NAME, TABLE_TYPE FROM information_schema.TABLES WHERE TABLE_SCHEMA=%s", (arguments.database,))
tables = cursor.fetchall()
for table_name, table_type in tables:
    cursor.execute("SELECT COUNT(*) FROM `" + arguments.database + "`.`" + table_name + "`")
    source_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM `" + restored_name + "`.`" + table_name + "`")
    assert cursor.fetchone()[0] == source_count
for metadata_table, schema_column in [("ROUTINES", "ROUTINE_SCHEMA"), ("TRIGGERS", "TRIGGER_SCHEMA"), ("EVENTS", "EVENT_SCHEMA")]:
    count_query = "SELECT COUNT(*) FROM information_schema." + metadata_table + " WHERE " + schema_column + "=%s"
    cursor.execute(count_query, (arguments.database,))
    source_count = cursor.fetchone()[0]
    cursor.execute(count_query, (restored_name,))
    assert cursor.fetchone()[0] == source_count

# Check that restored accounting and a restored procedure still work.
cursor.execute("SELECT SUM(amount_paid) FROM `" + restored_name + "`.Repayments")
collected = cursor.fetchone()[0]
cursor.execute("SELECT SUM(total_amount) FROM `" + restored_name + "`.InvestorPayouts")
assert cursor.fetchone()[0] == collected
cursor.execute("CALL `" + restored_name + "`.calculate_interest(1)")
assert float(cursor.fetchone()[1]) == 1200
while cursor.nextset():
    if cursor.with_rows:
        cursor.fetchall()
cursor.execute("DROP DATABASE `" + restored_name + "`")
cursor.close()
connection.close()
print("PASS backup and restore: all tables/views, routines, triggers, event, interest calculation, and payout totals")
print("The source was unchanged; the temporary restored schema and backup file were removed.")
