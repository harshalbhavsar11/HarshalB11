# Run only on a disposable local MySQL server. See tests/README.md.
import argparse
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from decimal import Decimal
import os
from pathlib import Path
import secrets
import shutil
import subprocess
import time

import mysql.connector
from streamlit.testing.v1 import AppTest


# Require an explicit test flag and refuse the usual production MySQL port.
parser = argparse.ArgumentParser()
parser.add_argument("--disposable-server", action="store_true", required=True)
parser.add_argument("--port", type=int, default=3307)
parser.add_argument("--user", default="root")
arguments = parser.parse_args()
if arguments.port == 3306:
    raise SystemExit("Use a separate disposable server on a port other than 3306.")
project_folder = Path(__file__).resolve().parent.parent
run_number = datetime.now().strftime("%m%d%H%M%S")
database_name = "microfinance_test_" + run_number
admin_name = "mf_admin_" + run_number
reader_name = "mf_reader_" + run_number
reader_password = secrets.token_hex(16)
test_password = os.environ.get("MYSQL_TEST_PASSWORD", "")
connection_settings = {
    "host": "127.0.0.1", "port": arguments.port, "user": arguments.user,
    "password": test_password, "autocommit": True, "time_zone": "+05:30",
}
mysql_program = shutil.which("mysql")
if mysql_program is None:
    raise SystemExit("Add the MySQL bin directory to PATH before running this test.")


# Load real project files through the MySQL client, which understands DELIMITER.
def load_file(filename):
    source = (project_folder / filename).read_text(encoding="utf-8")
    source = source.replace("microfinance_sdg", database_name)
    source = source.replace("microfinance_admin", admin_name)
    source = source.replace("microfinance_investor", reader_name)
    source = source.replace("REPLACE_ADMIN_PASSWORD", secrets.token_hex(16))
    source = source.replace("REPLACE_INVESTOR_PASSWORD", reader_password)
    environment = os.environ.copy()
    environment["MYSQL_PWD"] = test_password
    result = subprocess.run(
        [mysql_program, "--protocol=TCP", "--host=127.0.0.1", f"--port={arguments.port}",
         f"--user={arguments.user}", "--default-character-set=utf8mb4"],
        input=source, text=True, capture_output=True, env=environment,
    )
    if result.returncode != 0:
        raise AssertionError(filename + ": " + result.stderr)
    print("PASS import:", filename)


# Keep small query helpers only in tests; the student app stays simple.
def query(connection, sql, parameters=()):
    cursor = connection.cursor()
    try:
        cursor.execute(sql, parameters)
        rows = []
        if cursor.with_rows:
            rows = cursor.fetchall()
        # CALL can return an additional empty result set; consume it before reuse.
        while cursor.nextset():
            if cursor.with_rows:
                cursor.fetchall()
        return rows
    finally:
        cursor.close()


def scalar(connection, sql, parameters=()):
    return query(connection, sql, parameters)[0][0]


def expect_error(connection, sql, expected_text):
    try:
        query(connection, sql)
    except mysql.connector.Error as error:
        assert expected_text.lower() in str(error).lower(), str(error)
    else:
        raise AssertionError("Expected a rejection: " + sql)


# Open a new session for each concurrent operation.
def separate_call(sql):
    connection = mysql.connector.connect(**connection_settings, database=database_name)
    try:
        query(connection, sql)
        return "success"
    except mysql.connector.Error as error:
        return str(error)
    finally:
        connection.close()


# Import all deliverables, including grants and the event definition.
for filename in ["schema.sql", "procedures.sql", "triggers_events.sql", "sample_data.sql", "views_and_queries.sql", "extras.sql"]:
    load_file(filename)
connection = mysql.connector.connect(**connection_settings, database=database_name)

# Validate the historical sample and money conservation before making test payments.
expected_counts = {"Borrowers": 20, "Investors": 10, "Loans": 30, "Investments": 51,
                   "Repayments": 132, "ImpactMetrics": 20, "InvestorPayouts": 80}
for table_name, expected in expected_counts.items():
    assert scalar(connection, "SELECT COUNT(*) FROM " + table_name) == expected
assert dict(query(connection, "SELECT status, COUNT(*) FROM Loans GROUP BY status")) == {
    "pending": 6, "funded": 2, "active": 16, "closed": 4, "defaulted": 2,
}
assert scalar(connection, "SELECT COUNT(*) FROM investor_returns WHERE wallet_balance <> 150000 - total_invested + total_received") == 0
assert scalar(connection, "SELECT SUM(total_amount) FROM InvestorPayouts") == scalar(connection, "SELECT SUM(amount_paid) FROM Repayments")
assert scalar(connection, "SELECT SUM(total_earned) FROM investor_returns") == scalar(connection, "SELECT SUM(interest_amount + penalty_amount) FROM InvestorPayouts")
assert scalar(connection, "SELECT COUNT(*) FROM information_schema.EVENTS WHERE EVENT_SCHEMA = %s", (database_name,)) == 1
print("PASS sample counts, wallets, payout totals, earnings, and event creation")

# Penalties and scores must not increase simply because a procedure is rerun.
before_fees = query(connection, "SELECT repayment_id, penalty_amount, status FROM Repayments ORDER BY repayment_id")
query(connection, "CALL update_penalties()")
query(connection, "CALL update_penalties()")
assert before_fees == query(connection, "SELECT repayment_id, penalty_amount, status FROM Repayments ORDER BY repayment_id")
before_scores = query(connection, "SELECT borrower_id, credit_score FROM Borrowers ORDER BY borrower_id")
query(connection, "CALL update_credit_scores()")
query(connection, "CALL update_credit_scores()")
assert before_scores == query(connection, "SELECT borrower_id, credit_score FROM Borrowers ORDER BY borrower_id")
print("PASS repeatable penalties and bounded credit-score recalculation")

# Validate clear errors and confirm failed funding never changes wallets or totals.
initial_wallets = query(connection, "SELECT investor_id, wallet_balance FROM Investors ORDER BY investor_id")
expect_error(connection, "CALL fund_loan(1, 1, 0)", "positive")
expect_error(connection, "CALL fund_loan(1, 1, -5)", "positive")
expect_error(connection, "CALL fund_loan(1, 1, NULL)", "positive")
expect_error(connection, "CALL fund_loan(1, 999999, 100)", "Loan not found")
expect_error(connection, "CALL fund_loan(999999, 1, 100)", "Investor not found")
expect_error(connection, "CALL fund_loan(1, 1, 999999)", "Insufficient wallet")
expect_error(connection, "CALL fund_loan(1, 1, 10001)", "Loan needs only")
assert initial_wallets == query(connection, "SELECT investor_id, wallet_balance FROM Investors ORDER BY investor_id")
assert scalar(connection, "SELECT amount_funded FROM Loans WHERE loan_id=1") == 0
print("PASS invalid amounts, missing records, insufficient funds, and rollback")

# Two contributions activate loan 1 and produce an exact 11200-rupee schedule.
interest = query(connection, "CALL calculate_interest(1)")
assert interest[0][1] == Decimal("1200.00")
query(connection, "CALL fund_loan(1, 1, 6000)")
query(connection, "CALL fund_loan(2, 1, 4000)")
assert scalar(connection, "SELECT status FROM Loans WHERE loan_id=1") == "active"
assert query(connection, "SELECT COUNT(*), SUM(amount_due), SUM(principal_due), SUM(interest_due) FROM Repayments WHERE loan_id=1")[0] == (12, Decimal("11200.00"), Decimal("10000.00"), Decimal("1200.00"))
assert scalar(connection, "SELECT amount_due FROM Repayments WHERE loan_id=1 AND installment_number=12") == Decimal("933.37")
expect_error(connection, "CALL fund_loan(3, 1, 1)", "already funded")
query(connection, "START TRANSACTION")
expect_error(connection, "CALL generate_schedule(1)", "already exists")
connection.rollback()
print("PASS simple interest, exact schedules, activation, and duplicate schedule rejection")

# Artificially fail schedule creation after a wallet debit to check full rollback.
query(connection, "CREATE TRIGGER reject_test_schedule BEFORE INSERT ON Repayments FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Test schedule failure'")
wallet_before = scalar(connection, "SELECT wallet_balance FROM Investors WHERE investor_id=3")
log_before = scalar(connection, "SELECT COUNT(*) FROM LoanStatusLog WHERE loan_id=3")
expect_error(connection, "CALL fund_loan(3, 3, 5000)", "Test schedule failure")
assert scalar(connection, "SELECT wallet_balance FROM Investors WHERE investor_id=3") == wallet_before
assert scalar(connection, "SELECT amount_funded FROM Loans WHERE loan_id=3") == 0
assert scalar(connection, "SELECT COUNT(*) FROM Investments WHERE loan_id=3") == 0
assert scalar(connection, "SELECT COUNT(*) FROM LoanStatusLog WHERE loan_id=3") == log_before
query(connection, "DROP TRIGGER reject_test_schedule")
print("PASS downstream schedule failure rolls back wallet, funding, investment, and audit")

# Pay an overdue row and ensure each component of the collection is conserved.
payment_id = scalar(connection, "SELECT MIN(repayment_id) FROM Repayments WHERE status='overdue'")
query(connection, f"CALL pay_installment({payment_id})")
collected = scalar(connection, "SELECT amount_paid FROM Repayments WHERE repayment_id=%s", (payment_id,))
distributed = scalar(connection, "SELECT SUM(total_amount) FROM InvestorPayouts WHERE repayment_id=%s", (payment_id,))
assert collected == distributed
wallets_after = query(connection, "SELECT investor_id, wallet_balance FROM Investors ORDER BY investor_id")
expect_error(connection, f"CALL pay_installment({payment_id})", "already paid")
expect_error(connection, "CALL pay_installment(999999)", "not found")
assert wallets_after == query(connection, "SELECT investor_id, wallet_balance FROM Investors ORDER BY investor_id")
print("PASS late payment, payout conservation, and duplicate-payment rejection")

# Force a failure on the second investor and verify that the first payout rolls back.
first_payment = scalar(connection, "SELECT MIN(repayment_id) FROM Repayments WHERE loan_id=1")
query(connection, "CREATE TRIGGER reject_test_payout BEFORE INSERT ON InvestorPayouts FOR EACH ROW BEGIN IF NEW.investor_id=2 THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Test payout failure'; END IF; END")
wallets_before = query(connection, "SELECT investor_id, wallet_balance FROM Investors ORDER BY investor_id")
expect_error(connection, f"CALL pay_installment({first_payment})", "Test payout failure")
assert wallets_before == query(connection, "SELECT investor_id, wallet_balance FROM Investors ORDER BY investor_id")
assert scalar(connection, "SELECT COUNT(*) FROM InvestorPayouts WHERE repayment_id=%s", (first_payment,)) == 0
assert scalar(connection, "SELECT status FROM Repayments WHERE repayment_id=%s", (first_payment,)) == "pending"
query(connection, "DROP TRIGGER reject_test_payout")

# Pay all installments, then check automatic closure and exact returned principal.
for payment in query(connection, "SELECT repayment_id FROM Repayments WHERE loan_id=1 ORDER BY installment_number"):
    query(connection, f"CALL pay_installment({payment[0]})")
assert scalar(connection, "SELECT status FROM Loans WHERE loan_id=1") == "closed"
assert scalar(connection, "SELECT COUNT(*) FROM LoanStatusLog WHERE loan_id=1 AND old_status='active' AND new_status='closed'") == 1
assert scalar(connection, "SELECT SUM(principal_amount) FROM InvestorPayouts JOIN Repayments USING(repayment_id) WHERE loan_id=1") == Decimal("10000.00")
print("PASS failed payout rollback, final closure, audit trigger, and principal recovery")

# Make three fresh loans for controlled multi-session tests.
query(connection, "INSERT INTO Loans (loan_id, borrower_id, amount_requested, interest_rate, term_months, created_date) VALUES (8001,1,10000,12,2,CURDATE()), (8002,1,10000,12,2,CURDATE()), (8003,1,10000,12,2,CURDATE())")
with ThreadPoolExecutor(max_workers=2) as pool:
    # Hold A's row lock. B must block, then reject the stale 8000-rupee request.
    query(connection, "START TRANSACTION")
    query(connection, "SELECT loan_id FROM Loans WHERE loan_id=8001 FOR UPDATE")
    future = pool.submit(separate_call, "CALL fund_loan(2,8001,8000)")
    time.sleep(0.4)
    assert not future.done()
    query(connection, "UPDATE Investors SET wallet_balance=wallet_balance-8000 WHERE investor_id=1")
    query(connection, "INSERT INTO Investments (investor_id,loan_id,amount,investment_date) VALUES (1,8001,8000,CURDATE())")
    query(connection, "UPDATE Loans SET amount_funded=8000 WHERE loan_id=8001")
    connection.commit()
    assert "2000.00" in future.result(timeout=10)
    assert scalar(connection, "SELECT amount_funded FROM Loans WHERE loan_id=8001") == 8000

    # Fill another loan while B waits and check the exact already-funded error.
    query(connection, "START TRANSACTION")
    query(connection, "SELECT loan_id FROM Loans WHERE loan_id=8002 FOR UPDATE")
    future = pool.submit(separate_call, "CALL fund_loan(2,8002,8000)")
    time.sleep(0.4)
    assert not future.done()
    query(connection, "UPDATE Investors SET wallet_balance=wallet_balance-10000 WHERE investor_id=1")
    query(connection, "INSERT INTO Investments (investor_id,loan_id,amount,investment_date) VALUES (1,8002,10000,CURDATE())")
    query(connection, "UPDATE Loans SET amount_funded=10000,status='active',funded_date=CURDATE() WHERE loan_id=8002")
    query(connection, "CALL generate_schedule(8002)")
    connection.commit()
    assert "Loan already funded" in future.result(timeout=10)

    # Queue both final payments behind a lock and check the closing trigger sees both.
    query(connection, "CALL fund_loan(1,8003,3333.33)")
    query(connection, "CALL fund_loan(1,8003,1000)")
    query(connection, "CALL fund_loan(2,8003,3333.33)")
    query(connection, "CALL fund_loan(3,8003,2333.34)")
    payments = query(connection, "SELECT repayment_id FROM Repayments WHERE loan_id=8003 ORDER BY installment_number")
    query(connection, "START TRANSACTION")
    query(connection, "SELECT loan_id FROM Loans WHERE loan_id=8003 FOR UPDATE")
    first_future = pool.submit(separate_call, f"CALL pay_installment({payments[0][0]})")
    second_future = pool.submit(separate_call, f"CALL pay_installment({payments[1][0]})")
    time.sleep(0.4)
    assert not first_future.done() and not second_future.done()
    connection.commit()
    assert first_future.result(timeout=10) == "success"
    assert second_future.result(timeout=10) == "success"
    assert scalar(connection, "SELECT status FROM Loans WHERE loan_id=8003") == "closed"
    assert scalar(connection, "SELECT COUNT(*) FROM InvestorPayouts JOIN Repayments USING(repayment_id) WHERE loan_id=8003") == 6
print("PASS real waiting, remaining-funds rejection, funded rejection, simultaneous final payments, repeat investors")

# Repeat the unsafe race in isolated tables and retain the real loan CHECK constraint.
other = mysql.connector.connect(**connection_settings, database=database_name)
query(connection, "CREATE TABLE UnsafeLoan (id INT PRIMARY KEY, funded DECIMAL(12,2)) ENGINE=InnoDB")
query(connection, "INSERT INTO UnsafeLoan VALUES(1,0)")
query(connection, "START TRANSACTION")
query(other, "START TRANSACTION")
assert scalar(connection, "SELECT funded FROM UnsafeLoan WHERE id=1") == 0
assert scalar(other, "SELECT funded FROM UnsafeLoan WHERE id=1") == 0
query(connection, "UPDATE UnsafeLoan SET funded=funded+8000 WHERE id=1")
connection.commit()
query(other, "UPDATE UnsafeLoan SET funded=funded+8000 WHERE id=1")
other.commit()
assert scalar(connection, "SELECT funded FROM UnsafeLoan WHERE id=1") == 16000
other.close()
expect_error(connection, "UPDATE Loans SET amount_funded=20000 WHERE loan_id=8001", "check constraint")
print("PASS unsafe overfunding reproduction and production CHECK protection")

# Test the actual read-only permissions, then render every dashboard page.
reader = mysql.connector.connect(host="127.0.0.1", port=arguments.port, user=reader_name,
                                 password=reader_password, database=database_name, autocommit=True)
assert scalar(reader, "SELECT COUNT(*) FROM investor_returns") == 10
expect_error(reader, "SELECT * FROM Investors", "denied")
expect_error(reader, "UPDATE Investors SET wallet_balance=0", "denied")
expect_error(reader, "CALL fund_loan(1,2,100)", "denied")
reader.close()
app = AppTest.from_file(str(project_folder / "app.py"), default_timeout=60)
app.secrets["mysql"] = {"host": "127.0.0.1", "port": arguments.port, "user": reader_name,
                        "password": reader_password, "database": database_name}
app.run()
assert not app.exception and not app.error
for page in ["Overview", "Loans and Borrowers", "Risk Dashboard", "Investors", "Repayments", "SDG Impact"]:
    app.sidebar.radio[0].set_value(page).run()
    assert not app.exception, str(app.exception)
    assert not app.error, str(app.error)
    assert len(app.dataframe) >= 1
    print("PASS dashboard:", page)
app.sidebar.radio[0].set_value("Loans and Borrowers").run()
app.selectbox[0].set_value("defaulted").run()
assert len(app.dataframe[0].value) == 2
app.selectbox[1].set_value("Rampur").run()
assert len(app.dataframe[0].value) == 1
print("PASS read-only grants and combined dashboard filters")

# Check money conservation once more after all concurrent and failed operations.
assert scalar(connection, "SELECT SUM(amount_paid) FROM Repayments") == scalar(connection, "SELECT SUM(total_amount) FROM InvestorPayouts")
assert scalar(connection, "SELECT COUNT(*) FROM investor_returns WHERE wallet_balance <> 150000 - total_invested + total_received") == 0
print("PASS final wallet and payout conservation")

# Delete only the uniquely named test database and accounts created by this script.
query(connection, "DROP DATABASE " + database_name)
query(connection, "DROP USER '" + reader_name + "'@'localhost'")
query(connection, "DROP USER '" + admin_name + "'@'localhost'")
connection.close()
print("ALL CHECKS PASSED; the temporary test schema and accounts were removed.")
