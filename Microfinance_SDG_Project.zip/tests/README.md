# Optional integration tests

These checks use real MySQL sessions and Streamlit's built-in AppTest. No extra Python testing packages are needed beyond `requirements.txt`.

Use a **disposable local MySQL server on port 3307**, separate from your main database. The test creates a uniquely named schema and two temporary accounts; it removes them after success. Its administrator account must be able to create schemas, users, procedures, triggers, and events. On failure, the test schema may remain for inspection. It never modifies `microfinance_sdg`.

Add MySQL's `bin` folder to PATH, install the project's Python requirements, then run:

```powershell
$env:MYSQL_TEST_PASSWORD = 'password_for_disposable_server'
.\.venv\Scripts\python.exe tests\integration_test.py --disposable-server --port 3307 --user root
Remove-Item Env:MYSQL_TEST_PASSWORD
```

For a disposable, local-only test server initialized with an empty password, leave `MYSQL_TEST_PASSWORD` unset. The script refuses port 3306. It creates temporary account passwords randomly and does not print them.

Checks cover SQL imports, sample counts, balances, exact rounding, missing/invalid input, duplicate schedule and payment rejection, repeated fees and credit scores, rollback after deliberately injected failures, automatic closure, audit entries, real row-lock waiting, simultaneous payments, an unsafe funding race, read-only grants, every dashboard page, and combined status/village filters.

The nightly event is verified as a stored definition; `update_penalties()` is exercised directly. The test does not wait until midnight or change the server-wide event scheduler. Backup restoration and browser appearance are separate checks described in `TEST_RESULTS.md`.

To test backup and restoration of a sample already loaded on that same disposable server:

```powershell
.\.venv\Scripts\python.exe tests\backup_restore_test.py --disposable-server --port 3307 --database microfinance_sdg
```

This reads the source, restores into a new uniquely named schema, checks table/view counts and stored objects, then removes its own restored schema and temporary dump. It does not overwrite the source.
