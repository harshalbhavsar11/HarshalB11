# Complete project code

Assumption: MySQL 8.0.16+, rupees, simple interest, full-installment payments, and one reporting SDG per loan.

The ten requested deliverables appear below in the requested order. Run SQL in the dependency order described in README.md.

## 1. schema.sql

````sql
-- Create a new database. This script deliberately does not delete an old project.
CREATE DATABASE microfinance_sdg CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE microfinance_sdg;

-- Keep a starting score so recalculating credit scores never adds points twice.
CREATE TABLE Borrowers (
    borrower_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    village VARCHAR(80) NOT NULL,
    business_type ENUM('farming', 'tailoring', 'shop', 'dairy', 'other') NOT NULL,
    credit_score INT NOT NULL DEFAULT 650,
    initial_credit_score INT NOT NULL DEFAULT 650,
    joined_date DATE NOT NULL,
    CHECK (credit_score BETWEEN 300 AND 900),
    CHECK (initial_credit_score BETWEEN 300 AND 900)
) ENGINE=InnoDB;

-- Money uses DECIMAL, which stores rupees and paise exactly.
CREATE TABLE Investors (
    investor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    wallet_balance DECIMAL(14,2) NOT NULL DEFAULT 0,
    CHECK (wallet_balance >= 0)
) ENGINE=InnoDB;

-- The funding date is the starting point for monthly due dates.
CREATE TABLE Loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    borrower_id INT NOT NULL,
    amount_requested DECIMAL(12,2) NOT NULL,
    amount_funded DECIMAL(12,2) NOT NULL DEFAULT 0,
    interest_rate DECIMAL(5,2) NOT NULL,
    term_months INT NOT NULL,
    status ENUM('pending', 'funded', 'active', 'closed', 'defaulted') NOT NULL DEFAULT 'pending',
    created_date DATE NOT NULL,
    funded_date DATE NULL,
    FOREIGN KEY (borrower_id) REFERENCES Borrowers(borrower_id),
    CHECK (amount_requested > 0),
    CHECK (amount_funded >= 0 AND amount_funded <= amount_requested),
    CHECK (interest_rate BETWEEN 0 AND 100),
    CHECK (term_months BETWEEN 1 AND 60),
    CHECK (funded_date IS NULL OR funded_date >= created_date),
    CHECK (status = 'pending' OR amount_funded = amount_requested)
) ENGINE=InnoDB;

-- One investor can contribute several times to the same loan.
CREATE TABLE Investments (
    investment_id INT AUTO_INCREMENT PRIMARY KEY,
    investor_id INT NOT NULL,
    loan_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    investment_date DATE NOT NULL,
    FOREIGN KEY (investor_id) REFERENCES Investors(investor_id),
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id),
    CHECK (amount > 0)
) ENGINE=InnoDB;

-- Separating principal and interest makes actual investor earnings easy to explain.
CREATE TABLE Repayments (
    repayment_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    installment_number INT NOT NULL,
    due_date DATE NOT NULL,
    principal_due DECIMAL(12,2) NOT NULL,
    interest_due DECIMAL(12,2) NOT NULL,
    amount_due DECIMAL(12,2) NOT NULL,
    amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0,
    penalty_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    status ENUM('pending', 'paid', 'overdue') NOT NULL DEFAULT 'pending',
    paid_date DATE NULL,
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id),
    UNIQUE (loan_id, installment_number),
    CHECK (installment_number > 0),
    CHECK (principal_due > 0 AND interest_due >= 0),
    CHECK (amount_due = principal_due + interest_due),
    CHECK (penalty_amount >= 0),
    CHECK ((status = 'paid' AND paid_date IS NOT NULL AND amount_paid = amount_due + penalty_amount)
        OR (status <> 'paid' AND paid_date IS NULL AND amount_paid = 0))
) ENGINE=InnoDB;

-- Each loan belongs to one reporting goal, preventing double counting of impact.
-- Income increase means estimated monthly household income increase, in rupees.
CREATE TABLE ImpactMetrics (
    impact_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL UNIQUE,
    jobs_created INT NOT NULL DEFAULT 0,
    income_increase DECIMAL(12,2) NOT NULL DEFAULT 0,
    hectares_farmed DECIMAL(8,2) NOT NULL DEFAULT 0,
    sdg_goal INT NOT NULL,
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id),
    CHECK (jobs_created >= 0 AND income_increase >= 0 AND hectares_farmed >= 0),
    CHECK (sdg_goal IN (1, 8))
) ENGINE=InnoDB;

-- The status trigger writes an audit entry whenever a status changes.
CREATE TABLE LoanStatusLog (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    old_status ENUM('pending', 'funded', 'active', 'closed', 'defaulted') NOT NULL,
    new_status ENUM('pending', 'funded', 'active', 'closed', 'defaulted') NOT NULL,
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id)
) ENGINE=InnoDB;

-- This extra ledger records real payouts, including the exact rounding in paise.
-- A returned principal is not profit; only interest and penalties are earnings.
CREATE TABLE InvestorPayouts (
    payout_id INT AUTO_INCREMENT PRIMARY KEY,
    repayment_id INT NOT NULL,
    investor_id INT NOT NULL,
    principal_amount DECIMAL(12,2) NOT NULL,
    interest_amount DECIMAL(12,2) NOT NULL,
    penalty_amount DECIMAL(12,2) NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL,
    paid_date DATE NOT NULL,
    FOREIGN KEY (repayment_id) REFERENCES Repayments(repayment_id),
    FOREIGN KEY (investor_id) REFERENCES Investors(investor_id),
    UNIQUE (repayment_id, investor_id),
    CHECK (principal_amount >= 0 AND interest_amount >= 0 AND penalty_amount >= 0),
    CHECK (total_amount = principal_amount + interest_amount + penalty_amount)
) ENGINE=InnoDB;
````

## 2. sample_data.sql

````sql
USE microfinance_sdg;
SET time_zone = '+05:30';

-- Load this once, after procedures.sql and triggers_events.sql, into empty tables.
-- Dates move with the day you load it, keeping the classroom demo useful later.
START TRANSACTION;

-- Twenty borrowers live in five villages and run five types of businesses.
INSERT INTO Borrowers (borrower_id, name, village, business_type, joined_date) VALUES
(1, 'Asha Patil', 'Rampur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(2, 'Ravi Kumar', 'Rampur', 'shop', CURDATE() - INTERVAL 2 YEAR),
(3, 'Meena Devi', 'Rampur', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(4, 'Suresh Yadav', 'Rampur', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(5, 'Lakshmi Rao', 'Sundarpur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(6, 'Imran Khan', 'Sundarpur', 'shop', CURDATE() - INTERVAL 2 YEAR),
(7, 'Pooja Shah', 'Sundarpur', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(8, 'Kiran Das', 'Sundarpur', 'other', CURDATE() - INTERVAL 2 YEAR),
(9, 'Anita Joshi', 'Devgaon', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(10, 'Mohan Singh', 'Devgaon', 'farming', CURDATE() - INTERVAL 2 YEAR),
(11, 'Fatima Ali', 'Devgaon', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(12, 'Deepak Verma', 'Devgaon', 'shop', CURDATE() - INTERVAL 2 YEAR),
(13, 'Sita Nair', 'Shivapur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(14, 'Arun Reddy', 'Shivapur', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(15, 'Rekha Sen', 'Shivapur', 'other', CURDATE() - INTERVAL 2 YEAR),
(16, 'Vijay More', 'Shivapur', 'shop', CURDATE() - INTERVAL 2 YEAR),
(17, 'Sunita Kale', 'Haripur', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(18, 'Rahul Das', 'Haripur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(19, 'Nisha Roy', 'Haripur', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(20, 'Ganesh Mali', 'Haripur', 'other', CURDATE() - INTERVAL 2 YEAR);

-- These are starting wallets; contributions below are deducted and payouts added.
INSERT INTO Investors (investor_id, name, email, wallet_balance) VALUES
(1, 'Aarav Mehta', 'aarav@example.com', 150000),
(2, 'Diya Kapoor', 'diya@example.com', 150000),
(3, 'Ishaan Gupta', 'ishaan@example.com', 150000),
(4, 'Kavya Menon', 'kavya@example.com', 150000),
(5, 'Neel Shah', 'neel@example.com', 150000),
(6, 'Priya Iyer', 'priya@example.com', 150000),
(7, 'Rohan Sethi', 'rohan@example.com', 150000),
(8, 'Sara Thomas', 'sara@example.com', 150000),
(9, 'Varun Bansal', 'varun@example.com', 150000),
(10, 'Zoya Sheikh', 'zoya@example.com', 150000);

-- Thirty loans start pending, then receive the historical contributions below.
INSERT INTO Loans (loan_id, borrower_id, amount_requested, interest_rate, term_months, created_date) VALUES
(1, 1, 10000, 12, 12, CURDATE() - INTERVAL 10 DAY),
(2, 2, 15000, 10, 6, CURDATE() - INTERVAL 12 DAY),
(3, 3, 5000, 8, 6, CURDATE() - INTERVAL 8 DAY),
(4, 4, 20000, 12, 6, CURDATE() - INTERVAL 15 DAY),
(5, 5, 25000, 10, 6, CURDATE() - INTERVAL 20 DAY),
(6, 6, 30000, 12, 12, CURDATE() - INTERVAL 18 DAY),
(7, 7, 12000, 12, 6, CURDATE() - INTERVAL 10 DAY),
(8, 8, 18000, 10, 6, CURDATE() - INTERVAL 10 DAY),
(9, 9, 24000, 12, 6, CURDATE() - INTERVAL 4 MONTH),
(10, 10, 30000, 10, 6, CURDATE() - INTERVAL 3 MONTH),
(11, 11, 15000, 12, 6, CURDATE() - INTERVAL 5 MONTH),
(12, 12, 20000, 10, 6, CURDATE() - INTERVAL 6 MONTH),
(13, 13, 36000, 12, 6, CURDATE() - INTERVAL 4 MONTH),
(14, 14, 18000, 10, 6, CURDATE() - INTERVAL 3 MONTH),
(15, 15, 12000, 12, 6, CURDATE() - INTERVAL 5 MONTH),
(16, 16, 25000, 12, 6, CURDATE() - INTERVAL 4 MONTH),
(17, 17, 10000, 10, 6, CURDATE() - INTERVAL 3 MONTH),
(18, 18, 42000, 12, 6, CURDATE() - INTERVAL 5 MONTH),
(19, 19, 30000, 10, 6, CURDATE() - INTERVAL 4 MONTH),
(20, 20, 15000, 12, 6, CURDATE() - INTERVAL 3 MONTH),
(21, 1, 50000, 10, 6, CURDATE() - INTERVAL 20 DAY),
(22, 5, 24000, 12, 6, CURDATE() - INTERVAL 20 DAY),
(23, 10, 36000, 10, 6, CURDATE() - INTERVAL 20 DAY),
(24, 13, 18000, 12, 6, CURDATE() - INTERVAL 20 DAY),
(25, 3, 12000, 12, 6, CURDATE() - INTERVAL 9 MONTH),
(26, 7, 18000, 10, 6, CURDATE() - INTERVAL 9 MONTH),
(27, 11, 24000, 12, 6, CURDATE() - INTERVAL 9 MONTH),
(28, 17, 30000, 10, 6, CURDATE() - INTERVAL 9 MONTH),
(29, 2, 20000, 12, 6, CURDATE() - INTERVAL 8 MONTH),
(30, 6, 40000, 12, 6, CURDATE() - INTERVAL 8 MONTH);

-- Three loans are partly funded; three have no contributions yet.
INSERT INTO Investments (investor_id, loan_id, amount, investment_date) VALUES
(1, 4, 4000, CURDATE() - INTERVAL 5 DAY),
(2, 5, 5000, CURDATE() - INTERVAL 5 DAY),
(3, 6, 6000, CURDATE() - INTERVAL 5 DAY);

-- Each fully funded loan has two investors: a 60% share and a 40% share.
-- MOD cycles through five pairs of investors: (1,6), (2,7), and so on.
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
SELECT MOD(loan_id - 7, 5) + 1, loan_id, amount_requested * 0.60,
       created_date + INTERVAL 5 DAY FROM Loans WHERE loan_id >= 7;
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
SELECT MOD(loan_id - 7, 5) + 6, loan_id, amount_requested * 0.40,
       created_date + INTERVAL 5 DAY FROM Loans WHERE loan_id >= 7;

-- Derive funded totals and wallets from the investment records.
UPDATE Loans AS loan SET amount_funded =
    (SELECT COALESCE(SUM(amount), 0) FROM Investments WHERE loan_id = loan.loan_id);
UPDATE Investors AS investor SET wallet_balance = wallet_balance -
    (SELECT COALESCE(SUM(amount), 0) FROM Investments WHERE investor_id = investor.investor_id);
UPDATE Loans SET status = 'funded', funded_date = created_date + INTERVAL 5 DAY WHERE loan_id >= 7;
UPDATE Loans SET status = 'active' WHERE loan_id >= 9;

-- Generate the historical schedules inside this same transaction.
CALL generate_schedule(9);
CALL generate_schedule(10);
CALL generate_schedule(11);
CALL generate_schedule(12);
CALL generate_schedule(13);
CALL generate_schedule(14);
CALL generate_schedule(15);
CALL generate_schedule(16);
CALL generate_schedule(17);
CALL generate_schedule(18);
CALL generate_schedule(19);
CALL generate_schedule(20);
CALL generate_schedule(21);
CALL generate_schedule(22);
CALL generate_schedule(23);
CALL generate_schedule(24);
CALL generate_schedule(25);
CALL generate_schedule(26);
CALL generate_schedule(27);
CALL generate_schedule(28);
CALL generate_schedule(29);
CALL generate_schedule(30);

-- Load past, on-time payments; the trigger closes loans 25 through 28.
UPDATE Repayments
SET status = 'paid', amount_paid = amount_due, paid_date = due_date - INTERVAL 1 DAY
WHERE (loan_id BETWEEN 9 AND 20 AND installment_number = 1)
   OR loan_id BETWEEN 25 AND 28
   OR (loan_id IN (29, 30) AND installment_number = 1);

-- Include two late payments with the one-time 2% fee.
UPDATE Repayments
SET status = 'paid', penalty_amount = ROUND(amount_due * 0.02, 2),
    amount_paid = amount_due + ROUND(amount_due * 0.02, 2), paid_date = due_date + INTERVAL 5 DAY
WHERE loan_id IN (29, 30) AND installment_number = 2;
UPDATE Loans SET status = 'defaulted' WHERE loan_id IN (29, 30);

-- Backfill the first investor's historical payout for each paid installment.
INSERT INTO InvestorPayouts (repayment_id, investor_id, principal_amount, interest_amount, penalty_amount, total_amount, paid_date)
SELECT repayment_id, MOD(loan_id - 7, 5) + 1,
       ROUND(principal_due * 0.60, 2), ROUND(interest_due * 0.60, 2), ROUND(penalty_amount * 0.60, 2),
       ROUND(principal_due * 0.60, 2) + ROUND(interest_due * 0.60, 2) + ROUND(penalty_amount * 0.60, 2), paid_date
FROM Repayments WHERE status = 'paid';

-- Give the second investor exactly the remainder, including leftover paise.
INSERT INTO InvestorPayouts (repayment_id, investor_id, principal_amount, interest_amount, penalty_amount, total_amount, paid_date)
SELECT payment.repayment_id, MOD(payment.loan_id - 7, 5) + 6,
       payment.principal_due - payout.principal_amount,
       payment.interest_due - payout.interest_amount,
       payment.penalty_amount - payout.penalty_amount,
       payment.amount_paid - payout.total_amount, payment.paid_date
FROM Repayments AS payment JOIN InvestorPayouts AS payout ON payout.repayment_id = payment.repayment_id
WHERE payment.status = 'paid';
UPDATE Investors AS investor SET wallet_balance = wallet_balance +
    (SELECT COALESCE(SUM(total_amount), 0) FROM InvestorPayouts WHERE investor_id = investor.investor_id);

-- Report impact for every active and closed loan, once per loan.
INSERT INTO ImpactMetrics (loan_id, jobs_created, income_increase, hectares_farmed, sdg_goal) VALUES
(9, 2, 2500, 0, 1), (10, 3, 3200, 1.5, 8), (11, 2, 2000, 0, 1),
(12, 1, 2200, 0, 8), (13, 4, 4500, 2.0, 8), (14, 2, 1800, 0, 1),
(15, 1, 1500, 0, 1), (16, 2, 2800, 0, 8), (17, 1, 1600, 0, 1),
(18, 4, 5200, 2.5, 8), (19, 3, 3000, 0, 1), (20, 1, 1700, 0, 8),
(21, 5, 6000, 3.0, 8), (22, 2, 2800, 1.2, 1), (23, 3, 4200, 2.0, 8),
(24, 2, 2400, 1.0, 1), (25, 1, 1900, 0, 1), (26, 2, 2300, 0, 8),
(27, 3, 3100, 0, 8), (28, 2, 2600, 0, 1);

-- Classify remaining late installments and calculate repeatable credit scores.
CALL update_penalties();
CALL update_credit_scores();
COMMIT;

-- Expected loan counts: pending 6, funded 2, active 16, closed 4, defaulted 2.
SELECT status, COUNT(*) AS loan_count FROM Loans GROUP BY status;
````

## 3. procedures.sql

````sql
USE microfinance_sdg;
DELIMITER $$

-- Return simple interest as a one-row result, rounded to paise.
CREATE PROCEDURE calculate_interest(IN requested_loan_id INT)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Loans WHERE loan_id = requested_loan_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found.';
    END IF;
    SELECT loan_id,
           ROUND(amount_requested * interest_rate / 100 * term_months / 12, 2) AS total_interest
    FROM Loans WHERE loan_id = requested_loan_id;
END$$

-- This helper uses its caller's transaction. It never commits somebody else's work.
-- For a manual call: START TRANSACTION; CALL generate_schedule(id); COMMIT;
CREATE PROCEDURE generate_schedule(IN requested_loan_id INT)
BEGIN
    DECLARE loan_principal DECIMAL(12,2) DEFAULT NULL;
    DECLARE funded_principal DECIMAL(12,2);
    DECLARE annual_rate DECIMAL(5,2);
    DECLARE months_count INT;
    DECLARE start_date DATE;
    DECLARE loan_status VARCHAR(20);
    DECLARE total_interest DECIMAL(12,2);
    DECLARE monthly_principal DECIMAL(12,2);
    DECLARE monthly_interest DECIMAL(12,2);
    DECLARE current_principal DECIMAL(12,2);
    DECLARE current_interest DECIMAL(12,2);
    DECLARE month_number INT DEFAULT 1;

    -- Lock the parent before inspecting or inserting its schedule.
    SELECT amount_requested, amount_funded, interest_rate, term_months, funded_date, status
    INTO loan_principal, funded_principal, annual_rate, months_count, start_date, loan_status
    FROM Loans WHERE loan_id = requested_loan_id FOR UPDATE;
    IF loan_principal IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found.';
    END IF;
    IF funded_principal <> loan_principal OR start_date IS NULL
       OR loan_status NOT IN ('funded', 'active') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A fully funded loan and funding date are required.';
    END IF;
    IF EXISTS (SELECT 1 FROM Repayments WHERE loan_id = requested_loan_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A repayment schedule already exists.';
    END IF;

    -- Put any leftover paise into the last installment so the totals are exact.
    SET total_interest = ROUND(loan_principal * annual_rate / 100 * months_count / 12, 2);
    SET monthly_principal = TRUNCATE(loan_principal / months_count, 2);
    SET monthly_interest = TRUNCATE(total_interest / months_count, 2);
    WHILE month_number <= months_count DO
        SET current_principal = monthly_principal;
        SET current_interest = monthly_interest;
        IF month_number = months_count THEN
            SET current_principal = loan_principal - monthly_principal * (months_count - 1);
            SET current_interest = total_interest - monthly_interest * (months_count - 1);
        END IF;
        INSERT INTO Repayments (loan_id, installment_number, due_date, principal_due, interest_due, amount_due)
        VALUES (requested_loan_id, month_number, DATE_ADD(start_date, INTERVAL month_number MONTH),
                current_principal, current_interest, current_principal + current_interest);
        SET month_number = month_number + 1;
    END WHILE;
END$$

-- Fund a loan atomically. Call this procedure outside an existing transaction.
CREATE PROCEDURE fund_loan(IN requested_investor_id INT, IN requested_loan_id INT, IN funding_amount DECIMAL(12,2))
BEGIN
    DECLARE loan_amount DECIMAL(12,2) DEFAULT NULL;
    DECLARE already_funded DECIMAL(12,2);
    DECLARE investor_wallet DECIMAL(14,2) DEFAULT NULL;
    DECLARE loan_status VARCHAR(20);
    DECLARE error_message VARCHAR(128);

    -- Any error, including a failed INSERT or deadlock, undoes every step.
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;

    -- All money procedures lock the loan first, then the affected money rows.
    SELECT amount_requested, amount_funded, status INTO loan_amount, already_funded, loan_status
    FROM Loans WHERE loan_id = requested_loan_id FOR UPDATE;
    IF loan_amount IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found.';
    END IF;
    SELECT wallet_balance INTO investor_wallet FROM Investors
    WHERE investor_id = requested_investor_id FOR UPDATE;
    IF investor_wallet IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Investor not found.';
    END IF;

    -- Report each rejected request clearly, without changing balances.
    IF funding_amount IS NULL OR funding_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Funding amount must be positive.';
    END IF;
    IF already_funded = loan_amount THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan already funded.';
    END IF;
    IF loan_status <> 'pending' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only pending loans accept investments.';
    END IF;
    IF funding_amount > investor_wallet THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient wallet balance.';
    END IF;
    IF funding_amount > loan_amount - already_funded THEN
        SET error_message = CONCAT('Loan needs only Rs ', loan_amount - already_funded, '.');
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
    END IF;

    -- Debit the wallet and record the same contribution in both places.
    UPDATE Investors SET wallet_balance = wallet_balance - funding_amount
    WHERE investor_id = requested_investor_id;
    INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
    VALUES (requested_investor_id, requested_loan_id, funding_amount, CURDATE());
    UPDATE Loans SET amount_funded = amount_funded + funding_amount
    WHERE loan_id = requested_loan_id;

    -- Funding and the entire schedule either both succeed or both roll back.
    IF already_funded + funding_amount = loan_amount THEN
        UPDATE Loans SET status = 'active', funded_date = CURDATE()
        WHERE loan_id = requested_loan_id;
        CALL generate_schedule(requested_loan_id);
    END IF;
    COMMIT;
END$$

-- Pay a complete installment; partial payments are outside this small project.
CREATE PROCEDURE pay_installment(IN requested_repayment_id INT)
BEGIN
    DECLARE parent_loan_id INT DEFAULT NULL;
    DECLARE locked_loan_id INT;
    DECLARE loan_status VARCHAR(20);
    DECLARE payment_status VARCHAR(20);
    DECLARE payment_due_date DATE;
    DECLARE principal_due_amount DECIMAL(12,2);
    DECLARE interest_due_amount DECIMAL(12,2);
    DECLARE late_fee DECIMAL(12,2);
    DECLARE total_invested DECIMAL(12,2);
    DECLARE funded_principal DECIMAL(12,2);
    DECLARE current_investor_id INT DEFAULT 0;
    DECLARE next_investor_id INT;
    DECLARE investor_contribution DECIMAL(12,2);
    DECLARE cumulative_contribution DECIMAL(12,2) DEFAULT 0;
    DECLARE locked_wallet DECIMAL(14,2);
    DECLARE allocated_principal DECIMAL(12,2) DEFAULT 0;
    DECLARE allocated_interest DECIMAL(12,2) DEFAULT 0;
    DECLARE allocated_penalty DECIMAL(12,2) DEFAULT 0;
    DECLARE principal_share DECIMAL(12,2);
    DECLARE interest_share DECIMAL(12,2);
    DECLARE penalty_share DECIMAL(12,2);

    -- Errors undo the payment, all payouts, wallet changes, and trigger changes.
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    -- Find the parent ID before starting the transaction's consistent-read snapshot.
    -- After waiting for the loan lock, later reads must see prior committed payments.
    SELECT loan_id INTO parent_loan_id FROM Repayments WHERE repayment_id = requested_repayment_id;
    IF parent_loan_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Repayment not found.';
    END IF;
    START TRANSACTION;

    -- Lock loan -> repayment -> investors; one lock order reduces deadlocks.
    SELECT loan_id, status, amount_funded INTO locked_loan_id, loan_status, funded_principal
    FROM Loans WHERE loan_id = parent_loan_id FOR UPDATE;
    SELECT status, due_date, principal_due, interest_due, penalty_amount
    INTO payment_status, payment_due_date, principal_due_amount, interest_due_amount, late_fee
    FROM Repayments WHERE repayment_id = requested_repayment_id FOR UPDATE;
    IF payment_status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Repayment not found.';
    END IF;
    IF payment_status = 'paid' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Installment already paid.';
    END IF;
    IF loan_status NOT IN ('active', 'defaulted') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This loan is not open for repayment.';
    END IF;

    -- Even if the nightly event has not run, a late payment includes its fee.
    IF payment_due_date < CURDATE() THEN
        SET late_fee = ROUND((principal_due_amount + interest_due_amount) * 0.02, 2);
    END IF;
    SELECT COALESCE(SUM(amount), 0) INTO total_invested
    FROM Investments WHERE loan_id = parent_loan_id;
    IF total_invested <= 0 OR total_invested <> funded_principal THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Investment totals do not match this loan.';
    END IF;

    -- Lock investors in ascending ID order and combine their repeat contributions.
    SELECT MIN(investor_id) INTO next_investor_id FROM Investments
    WHERE loan_id = parent_loan_id AND investor_id > current_investor_id;
    WHILE next_investor_id IS NOT NULL DO
        SET current_investor_id = next_investor_id;
        SELECT wallet_balance INTO locked_wallet FROM Investors
        WHERE investor_id = current_investor_id FOR UPDATE;
        SELECT SUM(amount) INTO investor_contribution FROM Investments
        WHERE loan_id = parent_loan_id AND investor_id = current_investor_id;
        SET cumulative_contribution = cumulative_contribution + investor_contribution;

        -- Round the running share, then subtract what was already given out.
        -- The last investor receives the remaining paise; no money is created.
        SET principal_share = ROUND(principal_due_amount * cumulative_contribution / total_invested, 2) - allocated_principal;
        SET interest_share = ROUND(interest_due_amount * cumulative_contribution / total_invested, 2) - allocated_interest;
        SET penalty_share = ROUND(late_fee * cumulative_contribution / total_invested, 2) - allocated_penalty;
        INSERT INTO InvestorPayouts (repayment_id, investor_id, principal_amount, interest_amount, penalty_amount, total_amount, paid_date)
        VALUES (requested_repayment_id, current_investor_id, principal_share, interest_share,
                penalty_share, principal_share + interest_share + penalty_share, CURDATE());
        UPDATE Investors SET wallet_balance = wallet_balance + principal_share + interest_share + penalty_share
        WHERE investor_id = current_investor_id;
        SET allocated_principal = allocated_principal + principal_share;
        SET allocated_interest = allocated_interest + interest_share;
        SET allocated_penalty = allocated_penalty + penalty_share;
        SELECT MIN(investor_id) INTO next_investor_id FROM Investments
        WHERE loan_id = parent_loan_id AND investor_id > current_investor_id;
    END WHILE;

    -- The closing trigger runs inside this transaction after this update.
    UPDATE Repayments
    SET penalty_amount = late_fee, amount_paid = principal_due_amount + interest_due_amount + late_fee,
        status = 'paid', paid_date = CURDATE()
    WHERE repayment_id = requested_repayment_id;
    COMMIT;
END$$

-- Set one fixed fee, rather than adding another fee on every run.
CREATE PROCEDURE update_penalties()
BEGIN
    UPDATE Repayments
    SET status = 'overdue', penalty_amount = ROUND(amount_due * 0.02, 2)
    WHERE status <> 'paid' AND due_date < CURDATE();
END$$

-- Rebuild each score from its starting value, so repeating the call is safe.
-- On-time paid installment: +5. Late paid or currently overdue installment: -10.
CREATE PROCEDURE update_credit_scores()
BEGIN
    UPDATE Borrowers AS borrower
    SET credit_score = LEAST(900, GREATEST(300, initial_credit_score
        + 5 * (SELECT COUNT(*) FROM Loans AS loan JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
               WHERE loan.borrower_id = borrower.borrower_id AND payment.status = 'paid' AND payment.paid_date <= payment.due_date)
        - 10 * (SELECT COUNT(*) FROM Loans AS loan JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
                WHERE loan.borrower_id = borrower.borrower_id
                  AND ((payment.status = 'paid' AND payment.paid_date > payment.due_date)
                    OR (payment.status <> 'paid' AND payment.due_date < CURDATE())))));
END$$
DELIMITER ;
````

## 4. triggers_events.sql

````sql
USE microfinance_sdg;
DELIMITER $$

-- Close a loan only when its full schedule exists and every installment is paid.
CREATE TRIGGER close_fully_paid_loan
AFTER UPDATE ON Repayments
FOR EACH ROW
BEGIN
    DECLARE unpaid_count INT;
    DECLARE schedule_count INT;
    DECLARE expected_count INT;
    IF NEW.status = 'paid' AND OLD.status <> 'paid' THEN
        SELECT COUNT(*), COUNT(CASE WHEN status <> 'paid' THEN 1 END)
        INTO schedule_count, unpaid_count FROM Repayments WHERE loan_id = NEW.loan_id;
        SELECT term_months INTO expected_count FROM Loans WHERE loan_id = NEW.loan_id;
        IF unpaid_count = 0 AND schedule_count = expected_count THEN
            UPDATE Loans SET status = 'closed' WHERE loan_id = NEW.loan_id AND status <> 'closed';
        END IF;
    END IF;
END$$

-- Save the old and new status in the same transaction as the status change.
CREATE TRIGGER record_loan_status
AFTER UPDATE ON Loans
FOR EACH ROW
BEGIN
    IF OLD.status <> NEW.status THEN
        INSERT INTO LoanStatusLog (loan_id, old_status, new_status)
        VALUES (NEW.loan_id, OLD.status, NEW.status);
    END IF;
END$$
DELIMITER ;

-- Run at 00:05 each night in India time. A server administrator enables the scheduler.
SET time_zone = '+05:30';
CREATE EVENT nightly_penalty_update
ON SCHEDULE EVERY 1 DAY
STARTS TIMESTAMP(CURRENT_DATE + INTERVAL 1 DAY, '00:05:00')
DO CALL update_penalties();

-- Run separately as an administrator if the scheduler is OFF:
-- SET GLOBAL event_scheduler = ON;
-- SHOW VARIABLES LIKE 'event_scheduler';
````

## 5. views_and_queries.sql

````sql
USE microfinance_sdg;

-- 1. One row per overdue loan; days overdue refers to its oldest unpaid due date.
CREATE VIEW overdue_loans AS
SELECT loan.loan_id, borrower.name AS borrower_name, borrower.village,
       MIN(payment.due_date) AS oldest_unpaid_due_date,
       DATEDIFF(CURDATE(), MIN(payment.due_date)) AS days_overdue,
       COUNT(*) AS overdue_installments,
       SUM(payment.amount_due + payment.penalty_amount) AS overdue_amount
FROM Loans AS loan
JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id
JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
WHERE payment.status <> 'paid' AND payment.due_date < CURDATE()
GROUP BY loan.loan_id, borrower.name, borrower.village;
SELECT * FROM overdue_loans ORDER BY days_overdue DESC;

-- 2. Default percentage = currently defaulted / loans that reached disbursement.
-- Pending and funded-but-not-active loans are excluded from the denominator.
CREATE VIEW village_default_rates AS
SELECT borrower.village,
       COUNT(loan.loan_id) AS disbursed_loans,
       SUM(CASE WHEN loan.status = 'defaulted' THEN 1 ELSE 0 END) AS defaulted_loans,
       COALESCE(ROUND(100.0 * SUM(CASE WHEN loan.status = 'defaulted' THEN 1 ELSE 0 END)
                      / NULLIF(COUNT(loan.loan_id), 0), 2), 0) AS default_percentage
FROM Borrowers AS borrower
LEFT JOIN Loans AS loan ON loan.borrower_id = borrower.borrower_id
                      AND loan.status IN ('active', 'closed', 'defaulted')
GROUP BY borrower.village;
SELECT * FROM village_default_rates ORDER BY default_percentage DESC;

-- 3. Aggregate investments and payouts separately to avoid multiplying joined rows.
CREATE VIEW investor_investment_totals AS
SELECT investor_id, SUM(amount) AS total_invested FROM Investments GROUP BY investor_id;
CREATE VIEW investor_payout_totals AS
SELECT investor_id, SUM(principal_amount) AS principal_returned,
       SUM(interest_amount) AS interest_earned, SUM(penalty_amount) AS penalties_earned,
       SUM(total_amount) AS total_received
FROM InvestorPayouts GROUP BY investor_id;
CREATE VIEW investor_returns AS
SELECT investor.investor_id, investor.name, investor.wallet_balance,
       COALESCE(investment.total_invested, 0) AS total_invested,
       COALESCE(payout.principal_returned, 0) AS principal_returned,
       COALESCE(payout.interest_earned, 0) AS interest_earned,
       COALESCE(payout.penalties_earned, 0) AS penalties_earned,
       COALESCE(payout.interest_earned, 0) + COALESCE(payout.penalties_earned, 0) AS total_earned,
       COALESCE(payout.total_received, 0) AS total_received
FROM Investors AS investor
LEFT JOIN investor_investment_totals AS investment ON investment.investor_id = investor.investor_id
LEFT JOIN investor_payout_totals AS payout ON payout.investor_id = investor.investor_id;
SELECT * FROM investor_returns ORDER BY total_earned DESC;

-- 4. Compare only installments due by today; future installments do not lower a rate.
CREATE VIEW business_repayment_performance AS
SELECT borrower.business_type, COUNT(*) AS installments_due,
       SUM(CASE WHEN payment.status = 'paid' THEN 1 ELSE 0 END) AS installments_paid,
       ROUND(100.0 * SUM(CASE WHEN payment.status = 'paid' THEN 1 ELSE 0 END) / COUNT(*), 2) AS paid_percentage,
       ROUND(100.0 * SUM(CASE WHEN payment.status = 'paid' AND payment.paid_date <= payment.due_date
                             THEN 1 ELSE 0 END) / COUNT(*), 2) AS on_time_percentage
FROM Borrowers AS borrower
JOIN Loans AS loan ON loan.borrower_id = borrower.borrower_id
JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
WHERE payment.due_date <= CURDATE()
GROUP BY borrower.business_type;
SELECT * FROM business_repayment_performance ORDER BY on_time_percentage DESC;

-- A separate HAVING example finds types with at least three due installments.
SELECT borrower.business_type, COUNT(*) AS installments_due
FROM Borrowers AS borrower
JOIN Loans AS loan ON loan.borrower_id = borrower.borrower_id
JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
WHERE payment.due_date <= CURDATE()
GROUP BY borrower.business_type HAVING COUNT(*) >= 3;

-- 5. Use the same cohort for jobs and money: only loans with reported impact.
CREATE VIEW jobs_per_lakh AS
SELECT COALESCE(SUM(impact.jobs_created), 0) AS total_jobs,
       COALESCE(SUM(loan.amount_funded), 0) AS invested_in_reported_loans,
       COALESCE(ROUND(SUM(impact.jobs_created) * 100000.0 / NULLIF(SUM(loan.amount_funded), 0), 2), 0) AS jobs_per_lakh
FROM ImpactMetrics AS impact JOIN Loans AS loan ON loan.loan_id = impact.loan_id;
SELECT * FROM jobs_per_lakh;

-- 6. This is an overdue-based classroom risk rule, not a credit prediction model.
CREATE VIEW portfolio_risk AS
SELECT loan.loan_id, borrower.name AS borrower_name, borrower.village, loan.status,
       loan.amount_requested, loan.amount_funded,
       COALESCE(overdue.days_overdue, 0) AS days_overdue,
       CASE WHEN overdue.days_overdue > 30 THEN 'High'
            WHEN overdue.days_overdue BETWEEN 1 AND 30 THEN 'Medium'
            ELSE 'Low' END AS risk_level
FROM Loans AS loan
JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id
LEFT JOIN overdue_loans AS overdue ON overdue.loan_id = loan.loan_id;
SELECT * FROM portfolio_risk ORDER BY days_overdue DESC;

-- 7. Income increase is a monthly estimate; hectares are summed project areas.
CREATE VIEW sdg_summary AS
SELECT sdg_goal, COUNT(*) AS projects_reported, SUM(jobs_created) AS total_jobs_created,
       SUM(income_increase) AS total_monthly_income_increase,
       SUM(hectares_farmed) AS total_hectares_farmed
FROM ImpactMetrics GROUP BY sdg_goal;
SELECT * FROM sdg_summary;

-- Extra small views keep every dashboard query read-only and easy to understand.
CREATE VIEW dashboard_overview AS
SELECT COUNT(*) AS total_loans, COALESCE(SUM(amount_funded), 0) AS total_amount_lent,
       SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_loans,
       (SELECT COUNT(*) FROM overdue_loans) AS overdue_loans
FROM Loans;
CREATE VIEW loans_and_borrowers AS
SELECT loan.loan_id, borrower.borrower_id, borrower.name AS borrower_name,
       borrower.village, borrower.business_type, borrower.credit_score,
       loan.amount_requested, loan.amount_funded, loan.interest_rate, loan.term_months,
       loan.status, loan.created_date, loan.funded_date
FROM Loans AS loan JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id;
CREATE VIEW monthly_repayments AS
SELECT DATE_FORMAT(paid_date, '%Y-%m') AS payment_month,
       SUM(amount_paid) AS total_collected, COUNT(*) AS installments_paid
FROM Repayments WHERE status = 'paid'
GROUP BY DATE_FORMAT(paid_date, '%Y-%m');
CREATE VIEW repayment_details AS
SELECT repayment_id, loan_id, installment_number, due_date, principal_due, interest_due,
       amount_due, amount_paid, penalty_amount, status, paid_date
FROM Repayments;
````

## 6. extras.sql

````sql
USE microfinance_sdg;

-- InnoDB already indexes primary keys and foreign keys used for basic joins.
SHOW INDEX FROM Loans;
SHOW INDEX FROM Investments;
SHOW INDEX FROM Repayments;

-- Compare the same lookup before and after a useful two-column index.
EXPLAIN SELECT repayment_id, loan_id, due_date FROM Repayments
WHERE status = 'overdue' AND due_date < CURDATE();
CREATE INDEX index_repayments_status_due_date ON Repayments(status, due_date);
ANALYZE TABLE Repayments;
EXPLAIN SELECT repayment_id, loan_id, due_date FROM Repayments
WHERE status = 'overdue' AND due_date < CURDATE();

-- On a tiny sample MySQL may correctly prefer a full scan, even after indexing.
-- Compare possible_keys, key, type, and rows; do not claim timings from EXPLAIN.
CREATE INDEX index_investments_loan_investor ON Investments(loan_id, investor_id);
CREATE INDEX index_borrowers_village ON Borrowers(village);

-- Stop here unless you are the administrator and have edited both passwords below.
-- Replace these classroom placeholders with two passwords of your own before SOURCE.
CREATE USER 'microfinance_admin'@'localhost' IDENTIFIED BY 'REPLACE_ADMIN_PASSWORD';
CREATE USER 'microfinance_investor'@'localhost' IDENTIFIED BY 'REPLACE_INVESTOR_PASSWORD';

-- The admin manages this database, not every database on the server.
GRANT ALL PRIVILEGES ON microfinance_sdg.* TO 'microfinance_admin'@'localhost';

-- Views use their creator's permissions by default; this user cannot change money.
-- This is an aggregate classroom reporting account, not per-investor privacy isolation.
GRANT SELECT ON microfinance_sdg.overdue_loans TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.village_default_rates TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.investor_returns TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.business_repayment_performance TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.jobs_per_lakh TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.portfolio_risk TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.sdg_summary TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.dashboard_overview TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.loans_and_borrowers TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.monthly_repayments TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.repayment_details TO 'microfinance_investor'@'localhost';
SHOW GRANTS FOR 'microfinance_investor'@'localhost';

-- Read the audit trail together with the borrower name.
SELECT log.log_id, log.loan_id, borrower.name, log.old_status, log.new_status, log.changed_at
FROM LoanStatusLog AS log JOIN Loans AS loan ON loan.loan_id = log.loan_id
JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id
ORDER BY log.changed_at, log.log_id;

-- BACKUP: run in PowerShell or a terminal, not inside the MySQL prompt.
-- The result-file option avoids PowerShell text-encoding changes.
-- mysqldump -u root -p --single-transaction --routines --triggers --events --no-tablespaces --set-gtid-purged=OFF --databases microfinance_sdg --result-file=microfinance_backup.sql

-- RESTORE: first use a separate empty MySQL server for practice.
-- The backup includes CREATE DATABASE and USE, so do not restore it over live data.
-- mysql -u root -p --execute="SOURCE microfinance_backup.sql"

-- Account grants are not part of this database dump. Recreate only the CREATE USER
-- and GRANT section on the new server, after restoring the views and their definer.
-- Enable the event scheduler on that server if the nightly job should run there.
````

## 7. concurrency_demo.md

````markdown
# Two-session concurrency demonstration

Open two terminals and enter `mysql -u root -p` in each, or open two independent MySQL Workbench connections. Call them **Session A** and **Session B**. Run blocks in the numbered order. These examples are for a local classroom database.

**Arithmetic correction:** ₹8,000 + ₹8,000 exceeds ₹10,000. With locking, the second investor must see **₹2,000 remaining**, not “already funded.” The last example fills the loan first and produces the exact “Loan already funded.” message.

## 1. Without locking: both investors approve an old balance

The real `Loans` table has an extra CHECK constraint against overfunding. Keep that protection. Use these separate, deliberately unsafe demo tables to isolate the race. This is the second, simple version of the funding steps; it deliberately omits locking and rechecking inside UPDATE. MySQL still locks writes automatically, but the earlier checks can be stale.

**A — setup, once:**

```sql
USE microfinance_sdg;
-- These tables contain only throwaway classroom data.
CREATE TABLE DemoLoans (
    loan_id INT PRIMARY KEY,
    amount_requested DECIMAL(12,2) NOT NULL,
    amount_funded DECIMAL(12,2) NOT NULL DEFAULT 0
) ENGINE=InnoDB;
CREATE TABLE DemoInvestors (
    investor_id INT PRIMARY KEY,
    wallet_balance DECIMAL(12,2) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE DemoInvestments (
    investment_id INT AUTO_INCREMENT PRIMARY KEY,
    investor_id INT NOT NULL,
    loan_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL
) ENGINE=InnoDB;
INSERT INTO DemoLoans VALUES (1, 10000, 0);
INSERT INTO DemoInvestors VALUES (1, 20000), (2, 20000);
```

**A — read and approve, but pause before writing:**

```sql
START TRANSACTION;
-- A normal SELECT does not lock this loan for the funding check.
SELECT amount_requested - amount_funded INTO @remaining
FROM DemoLoans WHERE loan_id = 1;
SELECT wallet_balance INTO @wallet FROM DemoInvestors WHERE investor_id = 1;
SET @approved = (8000 > 0 AND 8000 <= @remaining AND 8000 <= @wallet);
SELECT @remaining, @approved; -- 10000, 1
```

**B — read and approve the same old balance:**

```sql
USE microfinance_sdg;
START TRANSACTION;
SELECT amount_requested - amount_funded INTO @remaining
FROM DemoLoans WHERE loan_id = 1;
SELECT wallet_balance INTO @wallet FROM DemoInvestors WHERE investor_id = 2;
SET @approved = (8000 > 0 AND 8000 <= @remaining AND 8000 <= @wallet);
SELECT @remaining, @approved; -- 10000, 1
```

**A — write using the earlier approval:**

```sql
UPDATE DemoInvestors SET wallet_balance = wallet_balance - 8000
WHERE investor_id = 1 AND @approved = 1;
UPDATE DemoLoans SET amount_funded = amount_funded + 8000
WHERE loan_id = 1 AND @approved = 1;
INSERT INTO DemoInvestments (investor_id, loan_id, amount)
SELECT 1, 1, 8000 WHERE @approved = 1;
COMMIT;
```

**B — use its stale approval after A commits:**

```sql
UPDATE DemoInvestors SET wallet_balance = wallet_balance - 8000
WHERE investor_id = 2 AND @approved = 1;
UPDATE DemoLoans SET amount_funded = amount_funded + 8000
WHERE loan_id = 1 AND @approved = 1;
INSERT INTO DemoInvestments (investor_id, loan_id, amount)
SELECT 2, 1, 8000 WHERE @approved = 1;
COMMIT;
SELECT * FROM DemoLoans; -- amount_funded = 16000: over-funded by 6000
SELECT SUM(amount) FROM DemoInvestments; -- 16000
```

Both reads approved ₹8,000 because each saw ₹10,000 available. The UPDATEs run one after another, but B still uses an old decision. A transaction alone does not make a read-then-write funding check safe. Lock the loan before checking its remaining amount.

## 2. With locking: B waits, then sees only ₹2,000 remaining

This uses the real tables, procedure, checks, and audit trigger. IDs 9001 and 9002 are reserved for this demo. Setup intentionally fails if they already exist, rather than deleting somebody's data. To repeat, use new IDs consistently or restore your classroom database.

**A — setup, once:**

```sql
USE microfinance_sdg;
INSERT INTO Borrowers (borrower_id, name, village, business_type, joined_date)
VALUES (9001, 'Concurrency Demo Borrower', 'Demo Village', 'shop', CURDATE());
INSERT INTO Investors (investor_id, name, email, wallet_balance) VALUES
(9001, 'Demo Investor A', 'demo.a@example.com', 30000),
(9002, 'Demo Investor B', 'demo.b@example.com', 30000);
INSERT INTO Loans (loan_id, borrower_id, amount_requested, interest_rate, term_months, created_date) VALUES
(9001, 9001, 10000, 12, 12, CURDATE()),
(9002, 9001, 10000, 12, 12, CURDATE());
```

**A — perform the first funding transaction manually and leave it open:**

```sql
START TRANSACTION;
SELECT amount_requested - amount_funded INTO @remaining
FROM Loans WHERE loan_id = 9001 FOR UPDATE;
SELECT wallet_balance INTO @wallet FROM Investors WHERE investor_id = 9001 FOR UPDATE;
SELECT @remaining, @wallet; -- 10000 and 30000; the fixed 8000 contribution is valid.
UPDATE Investors SET wallet_balance = wallet_balance - 8000 WHERE investor_id = 9001;
UPDATE Loans SET amount_funded = amount_funded + 8000 WHERE loan_id = 9001;
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
VALUES (9001, 9001, 8000, CURDATE());
-- PAUSE HERE. Do not commit yet. A owns the loan row lock.
```

**B — start this call; it waits at SELECT ... FOR UPDATE:**

```sql
USE microfinance_sdg;
SET SESSION innodb_lock_wait_timeout = 120;
CALL fund_loan(9002, 9001, 8000);
```

**A — release the lock within 120 seconds:**

```sql
COMMIT;
```

B now returns `Loan needs only Rs 2000.00.` Its handler rolls back. Verify in B:

```sql
SELECT loan_id, amount_funded, status FROM Loans WHERE loan_id = 9001; -- 8000, pending
SELECT wallet_balance FROM Investors WHERE investor_id = 9002; -- 30000, unchanged
-- B can now contribute exactly the remaining 2000; a 12-row schedule is generated.
CALL fund_loan(9002, 9001, 2000);
SELECT loan_id, amount_funded, status FROM Loans WHERE loan_id = 9001; -- 10000, active
SELECT COUNT(*) FROM Repayments WHERE loan_id = 9001; -- 12
```

## 3. With locking: exact “Loan already funded.” result

Use the second fresh ₹10,000 loan. A contributes the entire ₹10,000 this time.

**A — hold a valid fully funded transaction:**

```sql
START TRANSACTION;
SELECT amount_requested, amount_funded FROM Loans WHERE loan_id = 9002 FOR UPDATE;
SELECT wallet_balance FROM Investors WHERE investor_id = 9001 FOR UPDATE;
UPDATE Investors SET wallet_balance = wallet_balance - 10000 WHERE investor_id = 9001;
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
VALUES (9001, 9002, 10000, CURDATE());
UPDATE Loans SET amount_funded = 10000, status = 'active', funded_date = CURDATE() WHERE loan_id = 9002;
CALL generate_schedule(9002);
-- PAUSE before COMMIT.
```

**B — this call waits:**

```sql
CALL fund_loan(9002, 9002, 8000);
```

**A — finish, then inspect B's error:**

```sql
COMMIT;
```

B receives `Loan already funded.` Its wallet and the loan stay unchanged.

## Four viva lines

1. Without a locking read, both sessions can approve money using the same old balance.
2. `FOR UPDATE` lets only one session check and change that loan at a time.
3. After the first session commits, the second reads the new balance and rejects an excessive contribution.
4. `ROLLBACK` cancels every change in a failed transaction; `COMMIT` saves all successful changes together.

Do not put `CALL fund_loan` or `CALL pay_installment` inside an outer transaction: they own their transaction. The manual A blocks above make the wait visible; the procedures normally finish too quickly to demonstrate by eye. If a demo is interrupted while a manual transaction is open, run `ROLLBACK` in that session.
````

## 8. app.py

````python
# Import only the three requested libraries and one standard Python helper.
from decimal import Decimal

import mysql.connector
import pandas as pd
import streamlit as st


# Read the password from a private local file, not from this source code.
def get_connection():
    settings = st.secrets["mysql"]
    return mysql.connector.connect(
        host=settings.get("host", "127.0.0.1"),
        port=int(settings.get("port", 3306)),
        user=settings["user"],
        password=settings["password"],
        database=settings.get("database", "microfinance_sdg"),
        connection_timeout=5,
        autocommit=True,
        time_zone="+05:30",
    )


# Turn query results into a pandas table and always close the connection.
def read_table(query):
    connection = get_connection()
    try:
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute(query)
            rows = cursor.fetchall()
            column_names = cursor.column_names
        finally:
            cursor.close()
    finally:
        connection.close()

    # Chart libraries need ordinary numbers; database money still uses DECIMAL.
    table = pd.DataFrame(rows, columns=column_names)
    for column_name in table.columns:
        if not table.empty and isinstance(table[column_name].iloc[0], Decimal):
            table[column_name] = pd.to_numeric(table[column_name])
    return table


# Show the project title and six view-only pages.
st.set_page_config(page_title="Microfinance & SDG", page_icon="🌱", layout="wide")
st.title("Microfinance & Peer-to-Peer SDG Investment Engine")
st.caption("Small loans • Local businesses • Goal 1: No Poverty • Goal 8: Decent Work and Economic Growth")
page = st.sidebar.radio(
    "Choose a page",
    ["Overview", "Loans and Borrowers", "Risk Dashboard", "Investors", "Repayments", "SDG Impact"],
)
st.sidebar.caption("View-only dashboard. All money amounts are in Indian rupees.")
st.sidebar.button("Refresh data")

# Explain missing setup without showing a long Python error to a beginner.
try:
    database_settings = st.secrets["mysql"]
except (FileNotFoundError, KeyError):
    st.info("Copy .streamlit/secrets.toml.example to .streamlit/secrets.toml and enter your MySQL login. See README.md.")
    st.stop()


# Handle database errors once for all six pages.
try:
    if page == "Overview":
        st.header("Overview")
        overview = read_table("SELECT * FROM dashboard_overview").iloc[0]
        first, second, third, fourth = st.columns(4)
        first.metric("Total loans", int(overview["total_loans"]))
        second.metric("Total amount lent", f"₹{overview['total_amount_lent']:,.2f}")
        third.metric("Active loans", int(overview["active_loans"] or 0))
        fourth.metric("Overdue loans", int(overview["overdue_loans"]))
        st.caption("Amount lent includes every recorded contribution, including partial funding. Overdue loans have an unpaid installment due before today.")
        loans = read_table("SELECT * FROM loans_and_borrowers")
        if not loans.empty:
            status_counts = loans.groupby("status").size().rename("Loans")
            st.bar_chart(status_counts)
        st.dataframe(loans, hide_index=True)

    # Filter the pandas table; no user input is put into an SQL command.
    elif page == "Loans and Borrowers":
        st.header("Loans and Borrowers")
        loans = read_table("SELECT * FROM loans_and_borrowers ORDER BY loan_id")
        status = st.selectbox("Loan status", ["All", "pending", "funded", "active", "closed", "defaulted"])
        villages = sorted(loans["village"].dropna().unique().tolist())
        village = st.selectbox("Village", ["All"] + villages)
        if status != "All":
            loans = loans[loans["status"] == status]
        if village != "All":
            loans = loans[loans["village"] == village]
        st.dataframe(loans, hide_index=True)
        st.caption(f"{len(loans)} matching loans")

    # Streamlit's built-in Vega-Lite chart displays a pie without HTML or JavaScript.
    elif page == "Risk Dashboard":
        st.header("Risk Dashboard")
        risk = read_table("SELECT * FROM portfolio_risk ORDER BY days_overdue DESC")
        st.caption("Low: no overdue installment. Medium: 1–30 days overdue. High: more than 30 days. This simple rule includes pending and closed loans as Low.")
        if not risk.empty:
            risk_counts = risk.groupby("risk_level").size().reset_index(name="loan_count")
            st.vega_lite_chart(risk_counts, {
                "mark": {"type": "arc"},
                "encoding": {
                    "theta": {"field": "loan_count", "type": "quantitative"},
                    "color": {
                        "field": "risk_level", "type": "nominal",
                        "scale": {"domain": ["Low", "Medium", "High"], "range": ["#2a9d8f", "#e9c46a", "#e76f51"]},
                    },
                    "tooltip": [{"field": "risk_level"}, {"field": "loan_count"}],
                },
            })
        st.dataframe(risk, hide_index=True)
        defaults = read_table("SELECT * FROM village_default_rates ORDER BY village")
        st.subheader("Default percentage by village")
        if not defaults.empty:
            st.bar_chart(defaults.set_index("village")[["default_percentage"]])
        st.caption("Denominator: active, closed, and defaulted loans; pending and funded loans are excluded.")
        st.dataframe(defaults, hide_index=True)

    # Earnings include interest and late fees, but exclude returned principal.
    elif page == "Investors":
        st.header("Investors")
        investors = read_table("SELECT * FROM investor_returns ORDER BY investor_id")
        st.dataframe(investors, hide_index=True)
        st.caption("Total earned = interest earned + penalties earned. Principal returned is shown separately.")
        if not investors.empty:
            st.bar_chart(investors.set_index("name")[["total_invested", "total_earned"]])

    # Use the date money was received, rather than the installment's due date.
    elif page == "Repayments":
        st.header("Repayments")
        collected = read_table("SELECT * FROM monthly_repayments ORDER BY payment_month")
        if collected.empty:
            st.info("No repayments have been collected yet.")
        else:
            st.line_chart(collected.set_index("payment_month")[["total_collected"]])
        st.dataframe(collected, hide_index=True)
        payments = read_table("SELECT * FROM repayment_details ORDER BY due_date, repayment_id")
        st.dataframe(payments, hide_index=True)
        st.caption("Collections include principal, interest, and any late fee. Penalty amounts refresh when the nightly event runs or update_penalties() is called.")

    # Keep jobs, income, and hectares on separate charts because their units differ.
    elif page == "SDG Impact":
        st.header("SDG Impact")
        impact = read_table("SELECT * FROM sdg_summary ORDER BY sdg_goal")
        st.dataframe(impact, hide_index=True)
        if not impact.empty:
            impact["goal"] = impact["sdg_goal"].map({1: "Goal 1 — No Poverty", 8: "Goal 8 — Decent Work"})
            impact = impact.set_index("goal")
            first, second, third = st.columns(3)
            first.metric("Jobs created", int(impact["total_jobs_created"].sum()))
            second.metric("Monthly income increase", f"₹{impact['total_monthly_income_increase'].sum():,.2f}")
            third.metric("Hectares farmed", f"{impact['total_hectares_farmed'].sum():,.2f}")
            st.subheader("Jobs created")
            st.bar_chart(impact[["total_jobs_created"]])
            st.subheader("Monthly household income increase (₹)")
            st.bar_chart(impact[["total_monthly_income_increase"]])
            st.subheader("Hectares farmed")
            st.bar_chart(impact[["total_hectares_farmed"]])
        jobs = read_table("SELECT * FROM jobs_per_lakh").iloc[0]
        st.metric("Jobs per ₹1 lakh invested", f"{jobs['jobs_per_lakh']:,.2f}")
        st.caption("Only loans with reported impact enter this ratio. Each loan is assigned one SDG goal to avoid counting its impact twice.")

except mysql.connector.Error:
    st.error("Cannot read the database. Check that MySQL is running, your secrets file is correct, and the SQL files and view permissions are installed.")
    st.stop()
````

## 9. README.md

````markdown
# Microfinance & Peer-to-Peer SDG Investment Engine

A beginner-friendly DBMS project: MySQL manages small loans, investments, repayments, investor wallets, and social impact. Streamlit provides six read-only dashboard pages. Amounts are in Indian rupees.

## Assumptions

Use MySQL **8.0.16+** with InnoDB and Python **3.11+**. Interest is simple interest; installments are paid in full; the last installment absorbs rounding paise. A late installment gets one 2% fee, shared with investors. Each loan is assigned one reporting SDG, 1 or 8. Defaulting is an administrator's decision, not an automatic consequence of one late payment.

Small additions to the requested seven tables make the accounting accurate: `funded_date`, `paid_date`, principal/interest components, a starting credit score, and an eighth table, `InvestorPayouts`. See [VIVA_NOTES.md](VIVA_NOTES.md) for the ER diagram and explanations.

## 1. Install MySQL

Install MySQL Community Server from [the official download page](https://dev.mysql.com/downloads/mysql/) and optionally MySQL Workbench. Start the MySQL service and remember the root password. Add MySQL's `bin` directory to PATH, or use its full path.

On Windows, open PowerShell in this project folder and connect:

```powershell
mysql -u root -p
```

If it is not on PATH, use:

```powershell
& "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p
```

## 2. Load the database in dependency order

Run these commands **inside the MySQL prompt**, starting from this project directory. The sample uses procedures and triggers, so it runs after them even though it is second in the requested file listing.

```sql
SOURCE schema.sql;
SOURCE procedures.sql;
SOURCE triggers_events.sql;
SOURCE sample_data.sql;
SOURCE views_and_queries.sql;
```

Run each file once and stop if an error appears. These scripts do not drop your database. `sample_data.sql` is a one-time seed, not an upgrade script; if its transaction fails, run `ROLLBACK` and fix the error before continuing. Do not reload it over existing records. Sample status counts are 6 pending, 2 funded, 16 active, 4 closed, and 2 defaulted. There are 20 borrowers, 10 investors, 51 investments, 132 scheduled installments, 40 paid installments, 80 payouts, and 20 impact records.

Edit the two password placeholders in `extras.sql`, then run it as root:

```sql
SOURCE extras.sql;
SET GLOBAL event_scheduler = ON;
SHOW VARIABLES LIKE 'event_scheduler';
SHOW EVENTS FROM microfinance_sdg;
```

The event runs daily at 00:05 India time. `SET GLOBAL` lasts until restart; a server administrator can set `event_scheduler=ON` in MySQL's server configuration for persistence. If event creation is not permitted, create the triggers from the file and run `CALL update_penalties();` manually. Credit scores are recalculated manually with `CALL update_credit_scores();`.

`extras.sql` creates a database admin account and an investor reporting account with SELECT permission on dashboard views only. The investor account sees shared classroom summaries; it is not a private banking login. The optional funding button was omitted so the dashboard stays view-only.

## 3. Install Python libraries

Run in PowerShell, outside MySQL:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .streamlit\secrets.toml.example .streamlit\secrets.toml
```

Edit `.streamlit/secrets.toml` and enter the `microfinance_investor` password chosen in `extras.sql`. Use your MySQL server's port, normally 3306. The real secrets file is ignored by Git. On macOS/Linux, use `.venv/bin/python` in place of `.\.venv\Scripts\python.exe` and `cp` in place of `Copy-Item`.

## 4. Run the dashboard

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Open the local URL printed by Streamlit. After activating the virtual environment, the equivalent command is `streamlit run app.py`. The sidebar has Overview, Loans and Borrowers, Risk Dashboard, Investors, Repayments, and SDG Impact. All database queries are SELECTs on views.

## 5. Try the main procedures

These examples modify the classroom database. Use a fresh sample for repeatable results. Connect as root or the database admin, not the read-only dashboard account.

```sql
USE microfinance_sdg;
-- Loan 1: 10000 rupees at 12% for 12 months gives 1200 rupees interest.
CALL calculate_interest(1);
CALL fund_loan(1, 1, 6000);
CALL fund_loan(2, 1, 4000);
SELECT * FROM Repayments WHERE loan_id = 1;

-- Pick an actual repayment ID instead of assuming AUTO_INCREMENT starts at 1.
SELECT MIN(repayment_id) INTO @payment_id FROM Repayments WHERE loan_id = 1;
CALL pay_installment(@payment_id);
CALL update_penalties();
CALL update_credit_scores();
SELECT * FROM investor_returns WHERE investor_id IN (1, 2);
```

`fund_loan` and `pay_installment` start and finish their own transactions. Call them with no transaction already open. `generate_schedule` is a helper used inside a transaction that locks the loan. The two sample loans in `funded` state demonstrate an administrative stage before activation; normal `fund_loan` activates immediately on full funding. To activate one of those historical examples:

```sql
START TRANSACTION;
SELECT loan_id FROM Loans WHERE loan_id = 7 FOR UPDATE;
UPDATE Loans SET status = 'active' WHERE loan_id = 7;
CALL generate_schedule(7);
COMMIT;
```

Run `ROLLBACK` if any step in this manual transaction fails. Never edit investment totals, schedules, or wallets independently during normal use. The admin has broad access for teaching; ordinary money operations belong in the procedures. The payment procedure locks loan → repayment → investors in ascending ID order, reducing deadlocks between concurrent payments. If MySQL reports a deadlock or lock timeout, the procedure rolls back; retry the complete call.

## 6. Concurrency, backup, and verification

Follow [concurrency_demo.md](concurrency_demo.md) in two independent MySQL sessions. It includes an unsafe ₹16,000 result in isolated demo tables, a locked ₹2,000-remaining rejection, and the exact fully-funded error case.

Backup and restore commands, index EXPLAIN examples, grants, and the audit query are in `extras.sql`. Restore a backup on a separate practice server: restoring over an existing database replaces its tables. The dump includes procedures, triggers, and events, but not server accounts.

Automated database and dashboard checks are documented in [tests/README.md](tests/README.md). They require a **separate disposable MySQL server**, not your main project database. See [TEST_RESULTS.md](TEST_RESULTS.md) for the checks run during development.

## File guide (requested order)

1. `schema.sql` — tables, keys, constraints.
2. `sample_data.sql` — realistic historical sample and matching wallet ledger.
3. `procedures.sql` — interest, schedule, funding, payment, fees, credit scores.
4. `triggers_events.sql` — automatic closure, audit trail, nightly penalty event.
5. `views_and_queries.sql` — seven reports and dashboard views.
6. `extras.sql` — indexes, accounts, grants, backup and restore.
7. `concurrency_demo.md` — exact SQL for both sessions.
8. `app.py` — the six-page view-only dashboard.
9. `README.md` — this setup guide.
10. `VIVA_NOTES.md` — ER diagram, small numeric examples, and viva explanation.

## Official references

- [MySQL stored program restrictions](https://dev.mysql.com/doc/refman/8.0/en/stored-program-restrictions.html): triggers cannot begin transactions; the calling procedure owns the transaction.
- [Streamlit Vega-Lite charts](https://docs.streamlit.io/develop/api-reference/charts/st.vega_lite_chart): the built-in chart component used for the risk pie.
- [Streamlit app testing](https://docs.streamlit.io/develop/api-reference/app-testing/st.testing.v1.apptest): testing dashboard pages without manually clicking each page.
````

## 10. VIVA_NOTES.md

````markdown
# Viva notes and ER diagram

## 1. Tables: where each fact belongs

Borrowers borrow, investors contribute, loans hold the funding target, investments link investors to loans, repayments hold monthly dues, and impact records hold social results. LoanStatusLog records status changes. InvestorPayouts records money actually returned to each investor.

Example: borrower Asha requests ₹10,000. Investor A invests ₹6,000 and B invests ₹4,000. This is one loan with two investment rows. The investor-to-loan relationship is many-to-many, represented by Investments.

```mermaid
erDiagram
    Borrowers ||--o{ Loans : requests
    Investors ||--o{ Investments : contributes
    Loans ||--o{ Investments : receives
    Loans ||--o{ Repayments : schedules
    Loans ||--o| ImpactMetrics : reports
    Loans ||--o{ LoanStatusLog : records
    Repayments ||--o{ InvestorPayouts : distributes
    Investors ||--o{ InvestorPayouts : receives
```

Each child has a foreign key to its parent. A borrower can have many loans; a loan can have many installments and status log entries. A loan can have zero or one impact record, enforced by UNIQUE(loan_id). A paid installment has one payout per participating investor. UNIQUE(loan_id, installment_number) prevents duplicate monthly installments; UNIQUE(repayment_id, investor_id) prevents duplicate payout records.

## 2. Sample data: a small village lending portfolio

Twenty borrowers come from Rampur, Sundarpur, Devgaon, Shivapur, and Haripur. Ten investors start with ₹1,50,000 each. Thirty loans include pending, funded, active, closed, and defaulted examples. Some repayments are old, some are paid, and others are due in future months.

Example: a ₹20,000 loan with a ₹4,000 contribution is still pending and needs ₹16,000. Fully funded sample loans have a 60% investor and a 40% investor. Wallet balances equal starting cash minus investments plus actual payouts.

## 3. Procedures: reusable steps

- **calculate_interest:** principal × rate / 100 × months / 12. ₹10,000 × 12% × 12/12 = ₹1,200.
- **generate_schedule:** divide principal and interest across the months. For that loan, eleven installments are ₹933.33 and the last is ₹933.37; the total is exactly ₹11,200. The first due date is one month after funding.
- **fund_loan:** lock rows, validate the amount, debit the wallet, add an investment, and increase funding. A final ₹4,000 contribution after ₹6,000 activates the loan and creates the schedule.
- **pay_installment:** pay the full amount, including a late fee, and distribute it by investment share. For a ₹1,000 collection and a 60/40 split, investors receive ₹600 and ₹400. The ledger separates principal from earnings.
- **update_penalties:** an unpaid ₹1,000 installment past its due date gets a ₹20 fee. Running the procedure again keeps the fee at ₹20.
- **update_credit_scores:** starting score + 5 per on-time payment − 10 per late paid or currently overdue installment. Starting at 650, two on-time payments and one overdue installment give 650. Scores stay within 300–900; repeated calls give the same result if payment history has not changed.

Payment uses today's date, permits early payment, and rejects duplicate payment. There is no borrower wallet; calling the procedure represents receipt of the borrower's money. It does not connect to a real bank or payment gateway.

## 4. ACID and locking: keep related money changes together

| Property | Meaning in this project | Small example |
| --- | --- | --- |
| Atomicity | All transaction steps succeed together | If inserting an investment fails, the ₹8,000 wallet debit rolls back |
| Consistency | Rules hold before and after success | Funding never exceeds a loan's ₹10,000 target |
| Isolation | Concurrent operations cannot approve the same remaining money | B waits while A holds the loan's row lock |
| Durability | Committed changes survive normal server restarts | A committed ₹6,000 investment remains saved by InnoDB |

The SQL CHECK against overfunding is an additional guard. `FOR UPDATE` is still useful because it makes the check use the latest locked balance and gives a clear application error. Plain SELECT followed by UPDATE can use a stale approval even though UPDATE itself obtains a write lock. The unsafe demo uses separate tables without that CHECK so the race is visible.

The payment procedure locks the loan before its repayment row. This small change from the requested listing gives all operations a consistent parent-first order and reduces deadlocks. It also locks investor rows in ascending order. MySQL can still detect a deadlock; the error handler rolls back and the caller can retry the whole operation.

## 5. Triggers and the nightly event

The repayment trigger closes a loan when every scheduled installment is paid and the schedule has the expected number of rows. If installment 12 of 12 is the last unpaid one, paying it closes the loan. The status trigger records `active → closed` automatically in LoanStatusLog. Both actions roll back if the payment fails.

The event calls update_penalties every day at 00:05 India time. A ₹500 installment unpaid after yesterday's due date gets a ₹10 one-time penalty. The event scheduler must be enabled by the MySQL administrator. All parts use India time; the app explicitly sets the connection time zone.

## 6. Reports: questions answered by joins and groups

1. **Overdue loans:** join borrowers, loans, and repayments. A loan with unpaid due dates 5 and 40 days ago shows 40 days overdue, two overdue installments, and their summed debt.
2. **Village default rate:** currently defaulted / disbursed loans × 100. Two defaults among ten active, closed, or defaulted loans = 20%. Pending loans do not enter the denominator. No disbursed loans is displayed as 0% alongside a count of zero; it is not evidence of repayment success.
3. **Investor earnings:** sum actual interest and fee payouts. Receiving ₹1,100 made of ₹1,000 principal and ₹100 interest means ₹100 earned. Aggregate investments and payouts separately before joining, avoiding double counting.
4. **Business repayment performance:** compare installments whose due date has arrived. Eight paid on time out of ten due = 80% on-time performance. Paying late counts as paid but not on time. HAVING filters a completed group, such as business types with at least three due installments.
5. **Jobs per lakh:** jobs × 100000 / funded rupees for loans with reported impact. Six jobs supported by ₹2,00,000 = three jobs per lakh. Missing reports are excluded from both sides of this ratio.
6. **Risk:** Low means no unpaid overdue installment, Medium means 1–30 days, High means more than 30 days. Forty days overdue is High. This simple requested rule labels pending and fully repaid loans Low; it is not a forecast of default.
7. **SDG summary:** sum jobs, estimated monthly income increase, and hectares by goal. Two Goal 1 projects creating two and three jobs report five jobs. Each loan has one reporting goal, even if it helps both goals in real life.

LEFT JOIN keeps investors with no investments and villages with no disbursed loans visible. GROUP BY makes a row per investor, village, or business type. Views save reports for reuse by Streamlit.

## 7. Indexes, permissions, backup, and audit

An index is like a book's index: MySQL can find a matching status and due date without looking through every repayment. Primary and foreign keys already have indexes; the additional (status, due_date) index supports overdue filtering. EXPLAIN shows the plan before and after. With only 132 rows, a full scan may still be cheaper; do not invent a speedup.

The admin can manage the project database; the reporting user can only SELECT from views. An attempt by that user to change a ₹10,000 wallet is denied. A backup includes tables, data, procedures, triggers, and events; a restore recreates them on a practice server. Accounts need their own setup. Audit entries show when a status changed, for example `pending → active`; they are a classroom audit trail, not tamper-proof records against the full-access admin.

## 8. Dashboard

The UI only reads views. Overview shows counts and funded money. Loans and Borrowers filters by status and village. Risk shows a pie and village default bars. Investors separates investment from profit. Repayments groups collections by actual payment month, not due month. SDG Impact displays Goal 1 and Goal 8 separately.

Example: a June installment paid in July belongs to July collections. The optional funding button is omitted so a read-only reporting account can safely run every page.

## 9. Setup in one sentence

Install MySQL, create tables, install procedures and triggers, load the sample, create views and accounts, install Python dependencies, enter the reporting account password, and run `streamlit run app.py`.

## 10. A short project introduction

“My project connects investors with small village businesses. MySQL stores loans, contributions, repayment schedules, and social impact. Transactions and row locks keep concurrent funding correct. Triggers close repaid loans and record changes, while a nightly event marks overdue payments. A small Streamlit dashboard displays repayment risk, investor earnings, and progress toward SDG 1 and SDG 8.”
````

## Supporting file: requirements.txt

````text
mysql-connector-python>=9.0,<10
pandas>=2.2,<4
streamlit>=1.40,<2
````

## Supporting file: .streamlit/secrets.toml.example

````toml
# Copy this file to secrets.toml, then enter the account password chosen in extras.sql.
[mysql]
host = "127.0.0.1"
port = 3306
database = "microfinance_sdg"
user = "microfinance_investor"
password = "REPLACE_WITH_YOUR_INVESTOR_PASSWORD"
````
