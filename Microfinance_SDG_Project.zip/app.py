# Import only the three requested libraries and one standard Python helper.
from decimal import Decimal

import mysql.connector
import pandas as pd
import streamlit as st


# Read the password from a private local file, not from this source code.
def get_connection():
    settings = st.secrets["mysql"]
    return mysql.connector.connect(
        host=settings.get("host", "127.0.0.1"),
        port=int(settings.get("port", 3306)),
        user=settings["user"],
        password=settings["password"],
        database=settings.get("database", "microfinance_sdg"),
        connection_timeout=5,
        autocommit=True,
        time_zone="+05:30",
    )


# Turn query results into a pandas table and always close the connection.
def read_table(query):
    connection = get_connection()
    try:
        cursor = connection.cursor(dictionary=True)
        try:
            cursor.execute(query)
            rows = cursor.fetchall()
            column_names = cursor.column_names
        finally:
            cursor.close()
    finally:
        connection.close()

    # Chart libraries need ordinary numbers; database money still uses DECIMAL.
    table = pd.DataFrame(rows, columns=column_names)
    for column_name in table.columns:
        if not table.empty and isinstance(table[column_name].iloc[0], Decimal):
            table[column_name] = pd.to_numeric(table[column_name])
    return table


# Show the project title and six view-only pages.
st.set_page_config(page_title="Microfinance & SDG", page_icon="🌱", layout="wide")
st.title("Microfinance & Peer-to-Peer SDG Investment Engine")
st.caption("Small loans • Local businesses • Goal 1: No Poverty • Goal 8: Decent Work and Economic Growth")
page = st.sidebar.radio(
    "Choose a page",
    ["Overview", "Loans and Borrowers", "Risk Dashboard", "Investors", "Repayments", "SDG Impact"],
)
st.sidebar.caption("View-only dashboard. All money amounts are in Indian rupees.")
st.sidebar.button("Refresh data")

# Explain missing setup without showing a long Python error to a beginner.
try:
    database_settings = st.secrets["mysql"]
except (FileNotFoundError, KeyError):
    st.info("Copy .streamlit/secrets.toml.example to .streamlit/secrets.toml and enter your MySQL login. See README.md.")
    st.stop()


# Handle database errors once for all six pages.
try:
    if page == "Overview":
        st.header("Overview")
        overview = read_table("SELECT * FROM dashboard_overview").iloc[0]
        first, second, third, fourth = st.columns(4)
        first.metric("Total loans", int(overview["total_loans"]))
        second.metric("Total amount lent", f"₹{overview['total_amount_lent']:,.2f}")
        third.metric("Active loans", int(overview["active_loans"] or 0))
        fourth.metric("Overdue loans", int(overview["overdue_loans"]))
        st.caption("Amount lent includes every recorded contribution, including partial funding. Overdue loans have an unpaid installment due before today.")
        loans = read_table("SELECT * FROM loans_and_borrowers")
        if not loans.empty:
            status_counts = loans.groupby("status").size().rename("Loans")
            st.bar_chart(status_counts)
        st.dataframe(loans, hide_index=True)

    # Filter the pandas table; no user input is put into an SQL command.
    elif page == "Loans and Borrowers":
        st.header("Loans and Borrowers")
        loans = read_table("SELECT * FROM loans_and_borrowers ORDER BY loan_id")
        status = st.selectbox("Loan status", ["All", "pending", "funded", "active", "closed", "defaulted"])
        villages = sorted(loans["village"].dropna().unique().tolist())
        village = st.selectbox("Village", ["All"] + villages)
        if status != "All":
            loans = loans[loans["status"] == status]
        if village != "All":
            loans = loans[loans["village"] == village]
        st.dataframe(loans, hide_index=True)
        st.caption(f"{len(loans)} matching loans")

    # Streamlit's built-in Vega-Lite chart displays a pie without HTML or JavaScript.
    elif page == "Risk Dashboard":
        st.header("Risk Dashboard")
        risk = read_table("SELECT * FROM portfolio_risk ORDER BY days_overdue DESC")
        st.caption("Low: no overdue installment. Medium: 1–30 days overdue. High: more than 30 days. This simple rule includes pending and closed loans as Low.")
        if not risk.empty:
            risk_counts = risk.groupby("risk_level").size().reset_index(name="loan_count")
            st.vega_lite_chart(risk_counts, {
                "mark": {"type": "arc"},
                "encoding": {
                    "theta": {"field": "loan_count", "type": "quantitative"},
                    "color": {
                        "field": "risk_level", "type": "nominal",
                        "scale": {"domain": ["Low", "Medium", "High"], "range": ["#2a9d8f", "#e9c46a", "#e76f51"]},
                    },
                    "tooltip": [{"field": "risk_level"}, {"field": "loan_count"}],
                },
            })
        st.dataframe(risk, hide_index=True)
        defaults = read_table("SELECT * FROM village_default_rates ORDER BY village")
        st.subheader("Default percentage by village")
        if not defaults.empty:
            st.bar_chart(defaults.set_index("village")[["default_percentage"]])
        st.caption("Denominator: active, closed, and defaulted loans; pending and funded loans are excluded.")
        st.dataframe(defaults, hide_index=True)

    # Earnings include interest and late fees, but exclude returned principal.
    elif page == "Investors":
        st.header("Investors")
        investors = read_table("SELECT * FROM investor_returns ORDER BY investor_id")
        st.dataframe(investors, hide_index=True)
        st.caption("Total earned = interest earned + penalties earned. Principal returned is shown separately.")
        if not investors.empty:
            st.bar_chart(investors.set_index("name")[["total_invested", "total_earned"]])

    # Use the date money was received, rather than the installment's due date.
    elif page == "Repayments":
        st.header("Repayments")
        collected = read_table("SELECT * FROM monthly_repayments ORDER BY payment_month")
        if collected.empty:
            st.info("No repayments have been collected yet.")
        else:
            st.line_chart(collected.set_index("payment_month")[["total_collected"]])
        st.dataframe(collected, hide_index=True)
        payments = read_table("SELECT * FROM repayment_details ORDER BY due_date, repayment_id")
        st.dataframe(payments, hide_index=True)
        st.caption("Collections include principal, interest, and any late fee. Penalty amounts refresh when the nightly event runs or update_penalties() is called.")

    # Keep jobs, income, and hectares on separate charts because their units differ.
    elif page == "SDG Impact":
        st.header("SDG Impact")
        impact = read_table("SELECT * FROM sdg_summary ORDER BY sdg_goal")
        st.dataframe(impact, hide_index=True)
        if not impact.empty:
            impact["goal"] = impact["sdg_goal"].map({1: "Goal 1 — No Poverty", 8: "Goal 8 — Decent Work"})
            impact = impact.set_index("goal")
            first, second, third = st.columns(3)
            first.metric("Jobs created", int(impact["total_jobs_created"].sum()))
            second.metric("Monthly income increase", f"₹{impact['total_monthly_income_increase'].sum():,.2f}")
            third.metric("Hectares farmed", f"{impact['total_hectares_farmed'].sum():,.2f}")
            st.subheader("Jobs created")
            st.bar_chart(impact[["total_jobs_created"]])
            st.subheader("Monthly household income increase (₹)")
            st.bar_chart(impact[["total_monthly_income_increase"]])
            st.subheader("Hectares farmed")
            st.bar_chart(impact[["total_hectares_farmed"]])
        jobs = read_table("SELECT * FROM jobs_per_lakh").iloc[0]
        st.metric("Jobs per ₹1 lakh invested", f"{jobs['jobs_per_lakh']:,.2f}")
        st.caption("Only loans with reported impact enter this ratio. Each loan is assigned one SDG goal to avoid counting its impact twice.")

except mysql.connector.Error:
    st.error("Cannot read the database. Check that MySQL is running, your secrets file is correct, and the SQL files and view permissions are installed.")
    st.stop()
