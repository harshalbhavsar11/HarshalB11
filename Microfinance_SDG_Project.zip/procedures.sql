USE microfinance_sdg;
DELIMITER $$

-- Return simple interest as a one-row result, rounded to paise.
CREATE PROCEDURE calculate_interest(IN requested_loan_id INT)
BEGIN
    IF NOT EXISTS (SELECT 1 FROM Loans WHERE loan_id = requested_loan_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found.';
    END IF;
    SELECT loan_id,
           ROUND(amount_requested * interest_rate / 100 * term_months / 12, 2) AS total_interest
    FROM Loans WHERE loan_id = requested_loan_id;
END$$

-- This helper uses its caller's transaction. It never commits somebody else's work.
-- For a manual call: START TRANSACTION; CALL generate_schedule(id); COMMIT;
CREATE PROCEDURE generate_schedule(IN requested_loan_id INT)
BEGIN
    DECLARE loan_principal DECIMAL(12,2) DEFAULT NULL;
    DECLARE funded_principal DECIMAL(12,2);
    DECLARE annual_rate DECIMAL(5,2);
    DECLARE months_count INT;
    DECLARE start_date DATE;
    DECLARE loan_status VARCHAR(20);
    DECLARE total_interest DECIMAL(12,2);
    DECLARE monthly_principal DECIMAL(12,2);
    DECLARE monthly_interest DECIMAL(12,2);
    DECLARE current_principal DECIMAL(12,2);
    DECLARE current_interest DECIMAL(12,2);
    DECLARE month_number INT DEFAULT 1;

    -- Lock the parent before inspecting or inserting its schedule.
    SELECT amount_requested, amount_funded, interest_rate, term_months, funded_date, status
    INTO loan_principal, funded_principal, annual_rate, months_count, start_date, loan_status
    FROM Loans WHERE loan_id = requested_loan_id FOR UPDATE;
    IF loan_principal IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found.';
    END IF;
    IF funded_principal <> loan_principal OR start_date IS NULL
       OR loan_status NOT IN ('funded', 'active') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A fully funded loan and funding date are required.';
    END IF;
    IF EXISTS (SELECT 1 FROM Repayments WHERE loan_id = requested_loan_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A repayment schedule already exists.';
    END IF;

    -- Put any leftover paise into the last installment so the totals are exact.
    SET total_interest = ROUND(loan_principal * annual_rate / 100 * months_count / 12, 2);
    SET monthly_principal = TRUNCATE(loan_principal / months_count, 2);
    SET monthly_interest = TRUNCATE(total_interest / months_count, 2);
    WHILE month_number <= months_count DO
        SET current_principal = monthly_principal;
        SET current_interest = monthly_interest;
        IF month_number = months_count THEN
            SET current_principal = loan_principal - monthly_principal * (months_count - 1);
            SET current_interest = total_interest - monthly_interest * (months_count - 1);
        END IF;
        INSERT INTO Repayments (loan_id, installment_number, due_date, principal_due, interest_due, amount_due)
        VALUES (requested_loan_id, month_number, DATE_ADD(start_date, INTERVAL month_number MONTH),
                current_principal, current_interest, current_principal + current_interest);
        SET month_number = month_number + 1;
    END WHILE;
END$$

-- Fund a loan atomically. Call this procedure outside an existing transaction.
CREATE PROCEDURE fund_loan(IN requested_investor_id INT, IN requested_loan_id INT, IN funding_amount DECIMAL(12,2))
BEGIN
    DECLARE loan_amount DECIMAL(12,2) DEFAULT NULL;
    DECLARE already_funded DECIMAL(12,2);
    DECLARE investor_wallet DECIMAL(14,2) DEFAULT NULL;
    DECLARE loan_status VARCHAR(20);
    DECLARE error_message VARCHAR(128);

    -- Any error, including a failed INSERT or deadlock, undoes every step.
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    START TRANSACTION;

    -- All money procedures lock the loan first, then the affected money rows.
    SELECT amount_requested, amount_funded, status INTO loan_amount, already_funded, loan_status
    FROM Loans WHERE loan_id = requested_loan_id FOR UPDATE;
    IF loan_amount IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan not found.';
    END IF;
    SELECT wallet_balance INTO investor_wallet FROM Investors
    WHERE investor_id = requested_investor_id FOR UPDATE;
    IF investor_wallet IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Investor not found.';
    END IF;

    -- Report each rejected request clearly, without changing balances.
    IF funding_amount IS NULL OR funding_amount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Funding amount must be positive.';
    END IF;
    IF already_funded = loan_amount THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Loan already funded.';
    END IF;
    IF loan_status <> 'pending' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only pending loans accept investments.';
    END IF;
    IF funding_amount > investor_wallet THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Insufficient wallet balance.';
    END IF;
    IF funding_amount > loan_amount - already_funded THEN
        SET error_message = CONCAT('Loan needs only Rs ', loan_amount - already_funded, '.');
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = error_message;
    END IF;

    -- Debit the wallet and record the same contribution in both places.
    UPDATE Investors SET wallet_balance = wallet_balance - funding_amount
    WHERE investor_id = requested_investor_id;
    INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
    VALUES (requested_investor_id, requested_loan_id, funding_amount, CURDATE());
    UPDATE Loans SET amount_funded = amount_funded + funding_amount
    WHERE loan_id = requested_loan_id;

    -- Funding and the entire schedule either both succeed or both roll back.
    IF already_funded + funding_amount = loan_amount THEN
        UPDATE Loans SET status = 'active', funded_date = CURDATE()
        WHERE loan_id = requested_loan_id;
        CALL generate_schedule(requested_loan_id);
    END IF;
    COMMIT;
END$$

-- Pay a complete installment; partial payments are outside this small project.
CREATE PROCEDURE pay_installment(IN requested_repayment_id INT)
BEGIN
    DECLARE parent_loan_id INT DEFAULT NULL;
    DECLARE locked_loan_id INT;
    DECLARE loan_status VARCHAR(20);
    DECLARE payment_status VARCHAR(20);
    DECLARE payment_due_date DATE;
    DECLARE principal_due_amount DECIMAL(12,2);
    DECLARE interest_due_amount DECIMAL(12,2);
    DECLARE late_fee DECIMAL(12,2);
    DECLARE total_invested DECIMAL(12,2);
    DECLARE funded_principal DECIMAL(12,2);
    DECLARE current_investor_id INT DEFAULT 0;
    DECLARE next_investor_id INT;
    DECLARE investor_contribution DECIMAL(12,2);
    DECLARE cumulative_contribution DECIMAL(12,2) DEFAULT 0;
    DECLARE locked_wallet DECIMAL(14,2);
    DECLARE allocated_principal DECIMAL(12,2) DEFAULT 0;
    DECLARE allocated_interest DECIMAL(12,2) DEFAULT 0;
    DECLARE allocated_penalty DECIMAL(12,2) DEFAULT 0;
    DECLARE principal_share DECIMAL(12,2);
    DECLARE interest_share DECIMAL(12,2);
    DECLARE penalty_share DECIMAL(12,2);

    -- Errors undo the payment, all payouts, wallet changes, and trigger changes.
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    -- Find the parent ID before starting the transaction's consistent-read snapshot.
    -- After waiting for the loan lock, later reads must see prior committed payments.
    SELECT loan_id INTO parent_loan_id FROM Repayments WHERE repayment_id = requested_repayment_id;
    IF parent_loan_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Repayment not found.';
    END IF;
    START TRANSACTION;

    -- Lock loan -> repayment -> investors; one lock order reduces deadlocks.
    SELECT loan_id, status, amount_funded INTO locked_loan_id, loan_status, funded_principal
    FROM Loans WHERE loan_id = parent_loan_id FOR UPDATE;
    SELECT status, due_date, principal_due, interest_due, penalty_amount
    INTO payment_status, payment_due_date, principal_due_amount, interest_due_amount, late_fee
    FROM Repayments WHERE repayment_id = requested_repayment_id FOR UPDATE;
    IF payment_status IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Repayment not found.';
    END IF;
    IF payment_status = 'paid' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Installment already paid.';
    END IF;
    IF loan_status NOT IN ('active', 'defaulted') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'This loan is not open for repayment.';
    END IF;

    -- Even if the nightly event has not run, a late payment includes its fee.
    IF payment_due_date < CURDATE() THEN
        SET late_fee = ROUND((principal_due_amount + interest_due_amount) * 0.02, 2);
    END IF;
    SELECT COALESCE(SUM(amount), 0) INTO total_invested
    FROM Investments WHERE loan_id = parent_loan_id;
    IF total_invested <= 0 OR total_invested <> funded_principal THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Investment totals do not match this loan.';
    END IF;

    -- Lock investors in ascending ID order and combine their repeat contributions.
    SELECT MIN(investor_id) INTO next_investor_id FROM Investments
    WHERE loan_id = parent_loan_id AND investor_id > current_investor_id;
    WHILE next_investor_id IS NOT NULL DO
        SET current_investor_id = next_investor_id;
        SELECT wallet_balance INTO locked_wallet FROM Investors
        WHERE investor_id = current_investor_id FOR UPDATE;
        SELECT SUM(amount) INTO investor_contribution FROM Investments
        WHERE loan_id = parent_loan_id AND investor_id = current_investor_id;
        SET cumulative_contribution = cumulative_contribution + investor_contribution;

        -- Round the running share, then subtract what was already given out.
        -- The last investor receives the remaining paise; no money is created.
        SET principal_share = ROUND(principal_due_amount * cumulative_contribution / total_invested, 2) - allocated_principal;
        SET interest_share = ROUND(interest_due_amount * cumulative_contribution / total_invested, 2) - allocated_interest;
        SET penalty_share = ROUND(late_fee * cumulative_contribution / total_invested, 2) - allocated_penalty;
        INSERT INTO InvestorPayouts (repayment_id, investor_id, principal_amount, interest_amount, penalty_amount, total_amount, paid_date)
        VALUES (requested_repayment_id, current_investor_id, principal_share, interest_share,
                penalty_share, principal_share + interest_share + penalty_share, CURDATE());
        UPDATE Investors SET wallet_balance = wallet_balance + principal_share + interest_share + penalty_share
        WHERE investor_id = current_investor_id;
        SET allocated_principal = allocated_principal + principal_share;
        SET allocated_interest = allocated_interest + interest_share;
        SET allocated_penalty = allocated_penalty + penalty_share;
        SELECT MIN(investor_id) INTO next_investor_id FROM Investments
        WHERE loan_id = parent_loan_id AND investor_id > current_investor_id;
    END WHILE;

    -- The closing trigger runs inside this transaction after this update.
    UPDATE Repayments
    SET penalty_amount = late_fee, amount_paid = principal_due_amount + interest_due_amount + late_fee,
        status = 'paid', paid_date = CURDATE()
    WHERE repayment_id = requested_repayment_id;
    COMMIT;
END$$

-- Set one fixed fee, rather than adding another fee on every run.
CREATE PROCEDURE update_penalties()
BEGIN
    UPDATE Repayments
    SET status = 'overdue', penalty_amount = ROUND(amount_due * 0.02, 2)
    WHERE status <> 'paid' AND due_date < CURDATE();
END$$

-- Rebuild each score from its starting value, so repeating the call is safe.
-- On-time paid installment: +5. Late paid or currently overdue installment: -10.
CREATE PROCEDURE update_credit_scores()
BEGIN
    UPDATE Borrowers AS borrower
    SET credit_score = LEAST(900, GREATEST(300, initial_credit_score
        + 5 * (SELECT COUNT(*) FROM Loans AS loan JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
               WHERE loan.borrower_id = borrower.borrower_id AND payment.status = 'paid' AND payment.paid_date <= payment.due_date)
        - 10 * (SELECT COUNT(*) FROM Loans AS loan JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
                WHERE loan.borrower_id = borrower.borrower_id
                  AND ((payment.status = 'paid' AND payment.paid_date > payment.due_date)
                    OR (payment.status <> 'paid' AND payment.due_date < CURDATE())))));
END$$
DELIMITER ;
