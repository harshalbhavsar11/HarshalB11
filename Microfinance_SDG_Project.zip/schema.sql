-- Create a new database. This script deliberately does not delete an old project.
CREATE DATABASE microfinance_sdg CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE microfinance_sdg;

-- Keep a starting score so recalculating credit scores never adds points twice.
CREATE TABLE Borrowers (
    borrower_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    village VARCHAR(80) NOT NULL,
    business_type ENUM('farming', 'tailoring', 'shop', 'dairy', 'other') NOT NULL,
    credit_score INT NOT NULL DEFAULT 650,
    initial_credit_score INT NOT NULL DEFAULT 650,
    joined_date DATE NOT NULL,
    CHECK (credit_score BETWEEN 300 AND 900),
    CHECK (initial_credit_score BETWEEN 300 AND 900)
) ENGINE=InnoDB;

-- Money uses DECIMAL, which stores rupees and paise exactly.
CREATE TABLE Investors (
    investor_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    wallet_balance DECIMAL(14,2) NOT NULL DEFAULT 0,
    CHECK (wallet_balance >= 0)
) ENGINE=InnoDB;

-- The funding date is the starting point for monthly due dates.
CREATE TABLE Loans (
    loan_id INT AUTO_INCREMENT PRIMARY KEY,
    borrower_id INT NOT NULL,
    amount_requested DECIMAL(12,2) NOT NULL,
    amount_funded DECIMAL(12,2) NOT NULL DEFAULT 0,
    interest_rate DECIMAL(5,2) NOT NULL,
    term_months INT NOT NULL,
    status ENUM('pending', 'funded', 'active', 'closed', 'defaulted') NOT NULL DEFAULT 'pending',
    created_date DATE NOT NULL,
    funded_date DATE NULL,
    FOREIGN KEY (borrower_id) REFERENCES Borrowers(borrower_id),
    CHECK (amount_requested > 0),
    CHECK (amount_funded >= 0 AND amount_funded <= amount_requested),
    CHECK (interest_rate BETWEEN 0 AND 100),
    CHECK (term_months BETWEEN 1 AND 60),
    CHECK (funded_date IS NULL OR funded_date >= created_date),
    CHECK (status = 'pending' OR amount_funded = amount_requested)
) ENGINE=InnoDB;

-- One investor can contribute several times to the same loan.
CREATE TABLE Investments (
    investment_id INT AUTO_INCREMENT PRIMARY KEY,
    investor_id INT NOT NULL,
    loan_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL,
    investment_date DATE NOT NULL,
    FOREIGN KEY (investor_id) REFERENCES Investors(investor_id),
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id),
    CHECK (amount > 0)
) ENGINE=InnoDB;

-- Separating principal and interest makes actual investor earnings easy to explain.
CREATE TABLE Repayments (
    repayment_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    installment_number INT NOT NULL,
    due_date DATE NOT NULL,
    principal_due DECIMAL(12,2) NOT NULL,
    interest_due DECIMAL(12,2) NOT NULL,
    amount_due DECIMAL(12,2) NOT NULL,
    amount_paid DECIMAL(12,2) NOT NULL DEFAULT 0,
    penalty_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
    status ENUM('pending', 'paid', 'overdue') NOT NULL DEFAULT 'pending',
    paid_date DATE NULL,
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id),
    UNIQUE (loan_id, installment_number),
    CHECK (installment_number > 0),
    CHECK (principal_due > 0 AND interest_due >= 0),
    CHECK (amount_due = principal_due + interest_due),
    CHECK (penalty_amount >= 0),
    CHECK ((status = 'paid' AND paid_date IS NOT NULL AND amount_paid = amount_due + penalty_amount)
        OR (status <> 'paid' AND paid_date IS NULL AND amount_paid = 0))
) ENGINE=InnoDB;

-- Each loan belongs to one reporting goal, preventing double counting of impact.
-- Income increase means estimated monthly household income increase, in rupees.
CREATE TABLE ImpactMetrics (
    impact_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL UNIQUE,
    jobs_created INT NOT NULL DEFAULT 0,
    income_increase DECIMAL(12,2) NOT NULL DEFAULT 0,
    hectares_farmed DECIMAL(8,2) NOT NULL DEFAULT 0,
    sdg_goal INT NOT NULL,
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id),
    CHECK (jobs_created >= 0 AND income_increase >= 0 AND hectares_farmed >= 0),
    CHECK (sdg_goal IN (1, 8))
) ENGINE=InnoDB;

-- The status trigger writes an audit entry whenever a status changes.
CREATE TABLE LoanStatusLog (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    loan_id INT NOT NULL,
    old_status ENUM('pending', 'funded', 'active', 'closed', 'defaulted') NOT NULL,
    new_status ENUM('pending', 'funded', 'active', 'closed', 'defaulted') NOT NULL,
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (loan_id) REFERENCES Loans(loan_id)
) ENGINE=InnoDB;

-- This extra ledger records real payouts, including the exact rounding in paise.
-- A returned principal is not profit; only interest and penalties are earnings.
CREATE TABLE InvestorPayouts (
    payout_id INT AUTO_INCREMENT PRIMARY KEY,
    repayment_id INT NOT NULL,
    investor_id INT NOT NULL,
    principal_amount DECIMAL(12,2) NOT NULL,
    interest_amount DECIMAL(12,2) NOT NULL,
    penalty_amount DECIMAL(12,2) NOT NULL,
    total_amount DECIMAL(12,2) NOT NULL,
    paid_date DATE NOT NULL,
    FOREIGN KEY (repayment_id) REFERENCES Repayments(repayment_id),
    FOREIGN KEY (investor_id) REFERENCES Investors(investor_id),
    UNIQUE (repayment_id, investor_id),
    CHECK (principal_amount >= 0 AND interest_amount >= 0 AND penalty_amount >= 0),
    CHECK (total_amount = principal_amount + interest_amount + penalty_amount)
) ENGINE=InnoDB;
