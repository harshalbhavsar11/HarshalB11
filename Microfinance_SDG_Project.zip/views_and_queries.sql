USE microfinance_sdg;

-- 1. One row per overdue loan; days overdue refers to its oldest unpaid due date.
CREATE VIEW overdue_loans AS
SELECT loan.loan_id, borrower.name AS borrower_name, borrower.village,
       MIN(payment.due_date) AS oldest_unpaid_due_date,
       DATEDIFF(CURDATE(), MIN(payment.due_date)) AS days_overdue,
       COUNT(*) AS overdue_installments,
       SUM(payment.amount_due + payment.penalty_amount) AS overdue_amount
FROM Loans AS loan
JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id
JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
WHERE payment.status <> 'paid' AND payment.due_date < CURDATE()
GROUP BY loan.loan_id, borrower.name, borrower.village;
SELECT * FROM overdue_loans ORDER BY days_overdue DESC;

-- 2. Default percentage = currently defaulted / loans that reached disbursement.
-- Pending and funded-but-not-active loans are excluded from the denominator.
CREATE VIEW village_default_rates AS
SELECT borrower.village,
       COUNT(loan.loan_id) AS disbursed_loans,
       SUM(CASE WHEN loan.status = 'defaulted' THEN 1 ELSE 0 END) AS defaulted_loans,
       COALESCE(ROUND(100.0 * SUM(CASE WHEN loan.status = 'defaulted' THEN 1 ELSE 0 END)
                      / NULLIF(COUNT(loan.loan_id), 0), 2), 0) AS default_percentage
FROM Borrowers AS borrower
LEFT JOIN Loans AS loan ON loan.borrower_id = borrower.borrower_id
                      AND loan.status IN ('active', 'closed', 'defaulted')
GROUP BY borrower.village;
SELECT * FROM village_default_rates ORDER BY default_percentage DESC;

-- 3. Aggregate investments and payouts separately to avoid multiplying joined rows.
CREATE VIEW investor_investment_totals AS
SELECT investor_id, SUM(amount) AS total_invested FROM Investments GROUP BY investor_id;
CREATE VIEW investor_payout_totals AS
SELECT investor_id, SUM(principal_amount) AS principal_returned,
       SUM(interest_amount) AS interest_earned, SUM(penalty_amount) AS penalties_earned,
       SUM(total_amount) AS total_received
FROM InvestorPayouts GROUP BY investor_id;
CREATE VIEW investor_returns AS
SELECT investor.investor_id, investor.name, investor.wallet_balance,
       COALESCE(investment.total_invested, 0) AS total_invested,
       COALESCE(payout.principal_returned, 0) AS principal_returned,
       COALESCE(payout.interest_earned, 0) AS interest_earned,
       COALESCE(payout.penalties_earned, 0) AS penalties_earned,
       COALESCE(payout.interest_earned, 0) + COALESCE(payout.penalties_earned, 0) AS total_earned,
       COALESCE(payout.total_received, 0) AS total_received
FROM Investors AS investor
LEFT JOIN investor_investment_totals AS investment ON investment.investor_id = investor.investor_id
LEFT JOIN investor_payout_totals AS payout ON payout.investor_id = investor.investor_id;
SELECT * FROM investor_returns ORDER BY total_earned DESC;

-- 4. Compare only installments due by today; future installments do not lower a rate.
CREATE VIEW business_repayment_performance AS
SELECT borrower.business_type, COUNT(*) AS installments_due,
       SUM(CASE WHEN payment.status = 'paid' THEN 1 ELSE 0 END) AS installments_paid,
       ROUND(100.0 * SUM(CASE WHEN payment.status = 'paid' THEN 1 ELSE 0 END) / COUNT(*), 2) AS paid_percentage,
       ROUND(100.0 * SUM(CASE WHEN payment.status = 'paid' AND payment.paid_date <= payment.due_date
                             THEN 1 ELSE 0 END) / COUNT(*), 2) AS on_time_percentage
FROM Borrowers AS borrower
JOIN Loans AS loan ON loan.borrower_id = borrower.borrower_id
JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
WHERE payment.due_date <= CURDATE()
GROUP BY borrower.business_type;
SELECT * FROM business_repayment_performance ORDER BY on_time_percentage DESC;

-- A separate HAVING example finds types with at least three due installments.
SELECT borrower.business_type, COUNT(*) AS installments_due
FROM Borrowers AS borrower
JOIN Loans AS loan ON loan.borrower_id = borrower.borrower_id
JOIN Repayments AS payment ON payment.loan_id = loan.loan_id
WHERE payment.due_date <= CURDATE()
GROUP BY borrower.business_type HAVING COUNT(*) >= 3;

-- 5. Use the same cohort for jobs and money: only loans with reported impact.
CREATE VIEW jobs_per_lakh AS
SELECT COALESCE(SUM(impact.jobs_created), 0) AS total_jobs,
       COALESCE(SUM(loan.amount_funded), 0) AS invested_in_reported_loans,
       COALESCE(ROUND(SUM(impact.jobs_created) * 100000.0 / NULLIF(SUM(loan.amount_funded), 0), 2), 0) AS jobs_per_lakh
FROM ImpactMetrics AS impact JOIN Loans AS loan ON loan.loan_id = impact.loan_id;
SELECT * FROM jobs_per_lakh;

-- 6. This is an overdue-based classroom risk rule, not a credit prediction model.
CREATE VIEW portfolio_risk AS
SELECT loan.loan_id, borrower.name AS borrower_name, borrower.village, loan.status,
       loan.amount_requested, loan.amount_funded,
       COALESCE(overdue.days_overdue, 0) AS days_overdue,
       CASE WHEN overdue.days_overdue > 30 THEN 'High'
            WHEN overdue.days_overdue BETWEEN 1 AND 30 THEN 'Medium'
            ELSE 'Low' END AS risk_level
FROM Loans AS loan
JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id
LEFT JOIN overdue_loans AS overdue ON overdue.loan_id = loan.loan_id;
SELECT * FROM portfolio_risk ORDER BY days_overdue DESC;

-- 7. Income increase is a monthly estimate; hectares are summed project areas.
CREATE VIEW sdg_summary AS
SELECT sdg_goal, COUNT(*) AS projects_reported, SUM(jobs_created) AS total_jobs_created,
       SUM(income_increase) AS total_monthly_income_increase,
       SUM(hectares_farmed) AS total_hectares_farmed
FROM ImpactMetrics GROUP BY sdg_goal;
SELECT * FROM sdg_summary;

-- Extra small views keep every dashboard query read-only and easy to understand.
CREATE VIEW dashboard_overview AS
SELECT COUNT(*) AS total_loans, COALESCE(SUM(amount_funded), 0) AS total_amount_lent,
       SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) AS active_loans,
       (SELECT COUNT(*) FROM overdue_loans) AS overdue_loans
FROM Loans;
CREATE VIEW loans_and_borrowers AS
SELECT loan.loan_id, borrower.borrower_id, borrower.name AS borrower_name,
       borrower.village, borrower.business_type, borrower.credit_score,
       loan.amount_requested, loan.amount_funded, loan.interest_rate, loan.term_months,
       loan.status, loan.created_date, loan.funded_date
FROM Loans AS loan JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id;
CREATE VIEW monthly_repayments AS
SELECT DATE_FORMAT(paid_date, '%Y-%m') AS payment_month,
       SUM(amount_paid) AS total_collected, COUNT(*) AS installments_paid
FROM Repayments WHERE status = 'paid'
GROUP BY DATE_FORMAT(paid_date, '%Y-%m');
CREATE VIEW repayment_details AS
SELECT repayment_id, loan_id, installment_number, due_date, principal_due, interest_due,
       amount_due, amount_paid, penalty_amount, status, paid_date
FROM Repayments;
