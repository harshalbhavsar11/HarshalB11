# Viva notes and ER diagram

## 1. Tables: where each fact belongs

Borrowers borrow, investors contribute, loans hold the funding target, investments link investors to loans, repayments hold monthly dues, and impact records hold social results. LoanStatusLog records status changes. InvestorPayouts records money actually returned to each investor.

Example: borrower Asha requests ₹10,000. Investor A invests ₹6,000 and B invests ₹4,000. This is one loan with two investment rows. The investor-to-loan relationship is many-to-many, represented by Investments.

```mermaid
erDiagram
    Borrowers ||--o{ Loans : requests
    Investors ||--o{ Investments : contributes
    Loans ||--o{ Investments : receives
    Loans ||--o{ Repayments : schedules
    Loans ||--o| ImpactMetrics : reports
    Loans ||--o{ LoanStatusLog : records
    Repayments ||--o{ InvestorPayouts : distributes
    Investors ||--o{ InvestorPayouts : receives
```

Each child has a foreign key to its parent. A borrower can have many loans; a loan can have many installments and status log entries. A loan can have zero or one impact record, enforced by UNIQUE(loan_id). A paid installment has one payout per participating investor. UNIQUE(loan_id, installment_number) prevents duplicate monthly installments; UNIQUE(repayment_id, investor_id) prevents duplicate payout records.

## 2. Sample data: a small village lending portfolio

Twenty borrowers come from Rampur, Sundarpur, Devgaon, Shivapur, and Haripur. Ten investors start with ₹1,50,000 each. Thirty loans include pending, funded, active, closed, and defaulted examples. Some repayments are old, some are paid, and others are due in future months.

Example: a ₹20,000 loan with a ₹4,000 contribution is still pending and needs ₹16,000. Fully funded sample loans have a 60% investor and a 40% investor. Wallet balances equal starting cash minus investments plus actual payouts.

## 3. Procedures: reusable steps

- **calculate_interest:** principal × rate / 100 × months / 12. ₹10,000 × 12% × 12/12 = ₹1,200.
- **generate_schedule:** divide principal and interest across the months. For that loan, eleven installments are ₹933.33 and the last is ₹933.37; the total is exactly ₹11,200. The first due date is one month after funding.
- **fund_loan:** lock rows, validate the amount, debit the wallet, add an investment, and increase funding. A final ₹4,000 contribution after ₹6,000 activates the loan and creates the schedule.
- **pay_installment:** pay the full amount, including a late fee, and distribute it by investment share. For a ₹1,000 collection and a 60/40 split, investors receive ₹600 and ₹400. The ledger separates principal from earnings.
- **update_penalties:** an unpaid ₹1,000 installment past its due date gets a ₹20 fee. Running the procedure again keeps the fee at ₹20.
- **update_credit_scores:** starting score + 5 per on-time payment − 10 per late paid or currently overdue installment. Starting at 650, two on-time payments and one overdue installment give 650. Scores stay within 300–900; repeated calls give the same result if payment history has not changed.

Payment uses today's date, permits early payment, and rejects duplicate payment. There is no borrower wallet; calling the procedure represents receipt of the borrower's money. It does not connect to a real bank or payment gateway.

## 4. ACID and locking: keep related money changes together

| Property | Meaning in this project | Small example |
| --- | --- | --- |
| Atomicity | All transaction steps succeed together | If inserting an investment fails, the ₹8,000 wallet debit rolls back |
| Consistency | Rules hold before and after success | Funding never exceeds a loan's ₹10,000 target |
| Isolation | Concurrent operations cannot approve the same remaining money | B waits while A holds the loan's row lock |
| Durability | Committed changes survive normal server restarts | A committed ₹6,000 investment remains saved by InnoDB |

The SQL CHECK against overfunding is an additional guard. `FOR UPDATE` is still useful because it makes the check use the latest locked balance and gives a clear application error. Plain SELECT followed by UPDATE can use a stale approval even though UPDATE itself obtains a write lock. The unsafe demo uses separate tables without that CHECK so the race is visible.

The payment procedure locks the loan before its repayment row. This small change from the requested listing gives all operations a consistent parent-first order and reduces deadlocks. It also locks investor rows in ascending order. MySQL can still detect a deadlock; the error handler rolls back and the caller can retry the whole operation.

## 5. Triggers and the nightly event

The repayment trigger closes a loan when every scheduled installment is paid and the schedule has the expected number of rows. If installment 12 of 12 is the last unpaid one, paying it closes the loan. The status trigger records `active → closed` automatically in LoanStatusLog. Both actions roll back if the payment fails.

The event calls update_penalties every day at 00:05 India time. A ₹500 installment unpaid after yesterday's due date gets a ₹10 one-time penalty. The event scheduler must be enabled by the MySQL administrator. All parts use India time; the app explicitly sets the connection time zone.

## 6. Reports: questions answered by joins and groups

1. **Overdue loans:** join borrowers, loans, and repayments. A loan with unpaid due dates 5 and 40 days ago shows 40 days overdue, two overdue installments, and their summed debt.
2. **Village default rate:** currently defaulted / disbursed loans × 100. Two defaults among ten active, closed, or defaulted loans = 20%. Pending loans do not enter the denominator. No disbursed loans is displayed as 0% alongside a count of zero; it is not evidence of repayment success.
3. **Investor earnings:** sum actual interest and fee payouts. Receiving ₹1,100 made of ₹1,000 principal and ₹100 interest means ₹100 earned. Aggregate investments and payouts separately before joining, avoiding double counting.
4. **Business repayment performance:** compare installments whose due date has arrived. Eight paid on time out of ten due = 80% on-time performance. Paying late counts as paid but not on time. HAVING filters a completed group, such as business types with at least three due installments.
5. **Jobs per lakh:** jobs × 100000 / funded rupees for loans with reported impact. Six jobs supported by ₹2,00,000 = three jobs per lakh. Missing reports are excluded from both sides of this ratio.
6. **Risk:** Low means no unpaid overdue installment, Medium means 1–30 days, High means more than 30 days. Forty days overdue is High. This simple requested rule labels pending and fully repaid loans Low; it is not a forecast of default.
7. **SDG summary:** sum jobs, estimated monthly income increase, and hectares by goal. Two Goal 1 projects creating two and three jobs report five jobs. Each loan has one reporting goal, even if it helps both goals in real life.

LEFT JOIN keeps investors with no investments and villages with no disbursed loans visible. GROUP BY makes a row per investor, village, or business type. Views save reports for reuse by Streamlit.

## 7. Indexes, permissions, backup, and audit

An index is like a book's index: MySQL can find a matching status and due date without looking through every repayment. Primary and foreign keys already have indexes; the additional (status, due_date) index supports overdue filtering. EXPLAIN shows the plan before and after. With only 132 rows, a full scan may still be cheaper; do not invent a speedup.

The admin can manage the project database; the reporting user can only SELECT from views. An attempt by that user to change a ₹10,000 wallet is denied. A backup includes tables, data, procedures, triggers, and events; a restore recreates them on a practice server. Accounts need their own setup. Audit entries show when a status changed, for example `pending → active`; they are a classroom audit trail, not tamper-proof records against the full-access admin.

## 8. Dashboard

The UI only reads views. Overview shows counts and funded money. Loans and Borrowers filters by status and village. Risk shows a pie and village default bars. Investors separates investment from profit. Repayments groups collections by actual payment month, not due month. SDG Impact displays Goal 1 and Goal 8 separately.

Example: a June installment paid in July belongs to July collections. The optional funding button is omitted so a read-only reporting account can safely run every page.

## 9. Setup in one sentence

Install MySQL, create tables, install procedures and triggers, load the sample, create views and accounts, install Python dependencies, enter the reporting account password, and run `streamlit run app.py`.

## 10. A short project introduction

“My project connects investors with small village businesses. MySQL stores loans, contributions, repayment schedules, and social impact. Transactions and row locks keep concurrent funding correct. Triggers close repaid loans and record changes, while a nightly event marks overdue payments. A small Streamlit dashboard displays repayment risk, investor earnings, and progress toward SDG 1 and SDG 8.”
