# Microfinance & Peer-to-Peer SDG Investment Engine

A beginner-friendly DBMS project: MySQL manages small loans, investments, repayments, investor wallets, and social impact. Streamlit provides six read-only dashboard pages. Amounts are in Indian rupees.

## Assumptions

Use MySQL **8.0.16+** with InnoDB and Python **3.11+**. Interest is simple interest; installments are paid in full; the last installment absorbs rounding paise. A late installment gets one 2% fee, shared with investors. Each loan is assigned one reporting SDG, 1 or 8. Defaulting is an administrator's decision, not an automatic consequence of one late payment.

Small additions to the requested seven tables make the accounting accurate: `funded_date`, `paid_date`, principal/interest components, a starting credit score, and an eighth table, `InvestorPayouts`. See [VIVA_NOTES.md](VIVA_NOTES.md) for the ER diagram and explanations.

## 1. Install MySQL

Install MySQL Community Server from [the official download page](https://dev.mysql.com/downloads/mysql/) and optionally MySQL Workbench. Start the MySQL service and remember the root password. Add MySQL's `bin` directory to PATH, or use its full path.

On Windows, open PowerShell in this project folder and connect:

```powershell
mysql -u root -p
```

If it is not on PATH, use:

```powershell
& "C:\Program Files\MySQL\MySQL Server 8.0\bin\mysql.exe" -u root -p
```

## 2. Load the database in dependency order

Run these commands **inside the MySQL prompt**, starting from this project directory. The sample uses procedures and triggers, so it runs after them even though it is second in the requested file listing.

```sql
SOURCE schema.sql;
SOURCE procedures.sql;
SOURCE triggers_events.sql;
SOURCE sample_data.sql;
SOURCE views_and_queries.sql;
```

Run each file once and stop if an error appears. These scripts do not drop your database. `sample_data.sql` is a one-time seed, not an upgrade script; if its transaction fails, run `ROLLBACK` and fix the error before continuing. Do not reload it over existing records. Sample status counts are 6 pending, 2 funded, 16 active, 4 closed, and 2 defaulted. There are 20 borrowers, 10 investors, 51 investments, 132 scheduled installments, 40 paid installments, 80 payouts, and 20 impact records.

Edit the two password placeholders in `extras.sql`, then run it as root:

```sql
SOURCE extras.sql;
SET GLOBAL event_scheduler = ON;
SHOW VARIABLES LIKE 'event_scheduler';
SHOW EVENTS FROM microfinance_sdg;
```

The event runs daily at 00:05 India time. `SET GLOBAL` lasts until restart; a server administrator can set `event_scheduler=ON` in MySQL's server configuration for persistence. If event creation is not permitted, create the triggers from the file and run `CALL update_penalties();` manually. Credit scores are recalculated manually with `CALL update_credit_scores();`.

`extras.sql` creates a database admin account and an investor reporting account with SELECT permission on dashboard views only. The investor account sees shared classroom summaries; it is not a private banking login. The optional funding button was omitted so the dashboard stays view-only.

## 3. Install Python libraries

Run in PowerShell, outside MySQL:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .streamlit\secrets.toml.example .streamlit\secrets.toml
```

Edit `.streamlit/secrets.toml` and enter the `microfinance_investor` password chosen in `extras.sql`. Use your MySQL server's port, normally 3306. The real secrets file is ignored by Git. On macOS/Linux, use `.venv/bin/python` in place of `.\.venv\Scripts\python.exe` and `cp` in place of `Copy-Item`.

## 4. Run the dashboard

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Open the local URL printed by Streamlit. After activating the virtual environment, the equivalent command is `streamlit run app.py`. The sidebar has Overview, Loans and Borrowers, Risk Dashboard, Investors, Repayments, and SDG Impact. All database queries are SELECTs on views.

## 5. Try the main procedures

These examples modify the classroom database. Use a fresh sample for repeatable results. Connect as root or the database admin, not the read-only dashboard account.

```sql
USE microfinance_sdg;
-- Loan 1: 10000 rupees at 12% for 12 months gives 1200 rupees interest.
CALL calculate_interest(1);
CALL fund_loan(1, 1, 6000);
CALL fund_loan(2, 1, 4000);
SELECT * FROM Repayments WHERE loan_id = 1;

-- Pick an actual repayment ID instead of assuming AUTO_INCREMENT starts at 1.
SELECT MIN(repayment_id) INTO @payment_id FROM Repayments WHERE loan_id = 1;
CALL pay_installment(@payment_id);
CALL update_penalties();
CALL update_credit_scores();
SELECT * FROM investor_returns WHERE investor_id IN (1, 2);
```

`fund_loan` and `pay_installment` start and finish their own transactions. Call them with no transaction already open. `generate_schedule` is a helper used inside a transaction that locks the loan. The two sample loans in `funded` state demonstrate an administrative stage before activation; normal `fund_loan` activates immediately on full funding. To activate one of those historical examples:

```sql
START TRANSACTION;
SELECT loan_id FROM Loans WHERE loan_id = 7 FOR UPDATE;
UPDATE Loans SET status = 'active' WHERE loan_id = 7;
CALL generate_schedule(7);
COMMIT;
```

Run `ROLLBACK` if any step in this manual transaction fails. Never edit investment totals, schedules, or wallets independently during normal use. The admin has broad access for teaching; ordinary money operations belong in the procedures. The payment procedure locks loan → repayment → investors in ascending ID order, reducing deadlocks between concurrent payments. If MySQL reports a deadlock or lock timeout, the procedure rolls back; retry the complete call.

## 6. Concurrency, backup, and verification

Follow [concurrency_demo.md](concurrency_demo.md) in two independent MySQL sessions. It includes an unsafe ₹16,000 result in isolated demo tables, a locked ₹2,000-remaining rejection, and the exact fully-funded error case.

Backup and restore commands, index EXPLAIN examples, grants, and the audit query are in `extras.sql`. Restore a backup on a separate practice server: restoring over an existing database replaces its tables. The dump includes procedures, triggers, and events, but not server accounts.

Automated database and dashboard checks are documented in [tests/README.md](tests/README.md). They require a **separate disposable MySQL server**, not your main project database. See [TEST_RESULTS.md](TEST_RESULTS.md) for the checks run during development.

## File guide (requested order)

1. `schema.sql` — tables, keys, constraints.
2. `sample_data.sql` — realistic historical sample and matching wallet ledger.
3. `procedures.sql` — interest, schedule, funding, payment, fees, credit scores.
4. `triggers_events.sql` — automatic closure, audit trail, nightly penalty event.
5. `views_and_queries.sql` — seven reports and dashboard views.
6. `extras.sql` — indexes, accounts, grants, backup and restore.
7. `concurrency_demo.md` — exact SQL for both sessions.
8. `app.py` — the six-page view-only dashboard.
9. `README.md` — this setup guide.
10. `VIVA_NOTES.md` — ER diagram, small numeric examples, and viva explanation.

## Official references

- [MySQL stored program restrictions](https://dev.mysql.com/doc/refman/8.0/en/stored-program-restrictions.html): triggers cannot begin transactions; the calling procedure owns the transaction.
- [Streamlit Vega-Lite charts](https://docs.streamlit.io/develop/api-reference/charts/st.vega_lite_chart): the built-in chart component used for the risk pie.
- [Streamlit app testing](https://docs.streamlit.io/develop/api-reference/app-testing/st.testing.v1.apptest): testing dashboard pages without manually clicking each page.
