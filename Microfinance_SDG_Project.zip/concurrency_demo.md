# Two-session concurrency demonstration

Open two terminals and enter `mysql -u root -p` in each, or open two independent MySQL Workbench connections. Call them **Session A** and **Session B**. Run blocks in the numbered order. These examples are for a local classroom database.

**Arithmetic correction:** ₹8,000 + ₹8,000 exceeds ₹10,000. With locking, the second investor must see **₹2,000 remaining**, not “already funded.” The last example fills the loan first and produces the exact “Loan already funded.” message.

## 1. Without locking: both investors approve an old balance

The real `Loans` table has an extra CHECK constraint against overfunding. Keep that protection. Use these separate, deliberately unsafe demo tables to isolate the race. This is the second, simple version of the funding steps; it deliberately omits locking and rechecking inside UPDATE. MySQL still locks writes automatically, but the earlier checks can be stale.

**A — setup, once:**

```sql
USE microfinance_sdg;
-- These tables contain only throwaway classroom data.
CREATE TABLE DemoLoans (
    loan_id INT PRIMARY KEY,
    amount_requested DECIMAL(12,2) NOT NULL,
    amount_funded DECIMAL(12,2) NOT NULL DEFAULT 0
) ENGINE=InnoDB;
CREATE TABLE DemoInvestors (
    investor_id INT PRIMARY KEY,
    wallet_balance DECIMAL(12,2) NOT NULL
) ENGINE=InnoDB;
CREATE TABLE DemoInvestments (
    investment_id INT AUTO_INCREMENT PRIMARY KEY,
    investor_id INT NOT NULL,
    loan_id INT NOT NULL,
    amount DECIMAL(12,2) NOT NULL
) ENGINE=InnoDB;
INSERT INTO DemoLoans VALUES (1, 10000, 0);
INSERT INTO DemoInvestors VALUES (1, 20000), (2, 20000);
```

**A — read and approve, but pause before writing:**

```sql
START TRANSACTION;
-- A normal SELECT does not lock this loan for the funding check.
SELECT amount_requested - amount_funded INTO @remaining
FROM DemoLoans WHERE loan_id = 1;
SELECT wallet_balance INTO @wallet FROM DemoInvestors WHERE investor_id = 1;
SET @approved = (8000 > 0 AND 8000 <= @remaining AND 8000 <= @wallet);
SELECT @remaining, @approved; -- 10000, 1
```

**B — read and approve the same old balance:**

```sql
USE microfinance_sdg;
START TRANSACTION;
SELECT amount_requested - amount_funded INTO @remaining
FROM DemoLoans WHERE loan_id = 1;
SELECT wallet_balance INTO @wallet FROM DemoInvestors WHERE investor_id = 2;
SET @approved = (8000 > 0 AND 8000 <= @remaining AND 8000 <= @wallet);
SELECT @remaining, @approved; -- 10000, 1
```

**A — write using the earlier approval:**

```sql
UPDATE DemoInvestors SET wallet_balance = wallet_balance - 8000
WHERE investor_id = 1 AND @approved = 1;
UPDATE DemoLoans SET amount_funded = amount_funded + 8000
WHERE loan_id = 1 AND @approved = 1;
INSERT INTO DemoInvestments (investor_id, loan_id, amount)
SELECT 1, 1, 8000 WHERE @approved = 1;
COMMIT;
```

**B — use its stale approval after A commits:**

```sql
UPDATE DemoInvestors SET wallet_balance = wallet_balance - 8000
WHERE investor_id = 2 AND @approved = 1;
UPDATE DemoLoans SET amount_funded = amount_funded + 8000
WHERE loan_id = 1 AND @approved = 1;
INSERT INTO DemoInvestments (investor_id, loan_id, amount)
SELECT 2, 1, 8000 WHERE @approved = 1;
COMMIT;
SELECT * FROM DemoLoans; -- amount_funded = 16000: over-funded by 6000
SELECT SUM(amount) FROM DemoInvestments; -- 16000
```

Both reads approved ₹8,000 because each saw ₹10,000 available. The UPDATEs run one after another, but B still uses an old decision. A transaction alone does not make a read-then-write funding check safe. Lock the loan before checking its remaining amount.

## 2. With locking: B waits, then sees only ₹2,000 remaining

This uses the real tables, procedure, checks, and audit trigger. IDs 9001 and 9002 are reserved for this demo. Setup intentionally fails if they already exist, rather than deleting somebody's data. To repeat, use new IDs consistently or restore your classroom database.

**A — setup, once:**

```sql
USE microfinance_sdg;
INSERT INTO Borrowers (borrower_id, name, village, business_type, joined_date)
VALUES (9001, 'Concurrency Demo Borrower', 'Demo Village', 'shop', CURDATE());
INSERT INTO Investors (investor_id, name, email, wallet_balance) VALUES
(9001, 'Demo Investor A', 'demo.a@example.com', 30000),
(9002, 'Demo Investor B', 'demo.b@example.com', 30000);
INSERT INTO Loans (loan_id, borrower_id, amount_requested, interest_rate, term_months, created_date) VALUES
(9001, 9001, 10000, 12, 12, CURDATE()),
(9002, 9001, 10000, 12, 12, CURDATE());
```

**A — perform the first funding transaction manually and leave it open:**

```sql
START TRANSACTION;
SELECT amount_requested - amount_funded INTO @remaining
FROM Loans WHERE loan_id = 9001 FOR UPDATE;
SELECT wallet_balance INTO @wallet FROM Investors WHERE investor_id = 9001 FOR UPDATE;
SELECT @remaining, @wallet; -- 10000 and 30000; the fixed 8000 contribution is valid.
UPDATE Investors SET wallet_balance = wallet_balance - 8000 WHERE investor_id = 9001;
UPDATE Loans SET amount_funded = amount_funded + 8000 WHERE loan_id = 9001;
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
VALUES (9001, 9001, 8000, CURDATE());
-- PAUSE HERE. Do not commit yet. A owns the loan row lock.
```

**B — start this call; it waits at SELECT ... FOR UPDATE:**

```sql
USE microfinance_sdg;
SET SESSION innodb_lock_wait_timeout = 120;
CALL fund_loan(9002, 9001, 8000);
```

**A — release the lock within 120 seconds:**

```sql
COMMIT;
```

B now returns `Loan needs only Rs 2000.00.` Its handler rolls back. Verify in B:

```sql
SELECT loan_id, amount_funded, status FROM Loans WHERE loan_id = 9001; -- 8000, pending
SELECT wallet_balance FROM Investors WHERE investor_id = 9002; -- 30000, unchanged
-- B can now contribute exactly the remaining 2000; a 12-row schedule is generated.
CALL fund_loan(9002, 9001, 2000);
SELECT loan_id, amount_funded, status FROM Loans WHERE loan_id = 9001; -- 10000, active
SELECT COUNT(*) FROM Repayments WHERE loan_id = 9001; -- 12
```

## 3. With locking: exact “Loan already funded.” result

Use the second fresh ₹10,000 loan. A contributes the entire ₹10,000 this time.

**A — hold a valid fully funded transaction:**

```sql
START TRANSACTION;
SELECT amount_requested, amount_funded FROM Loans WHERE loan_id = 9002 FOR UPDATE;
SELECT wallet_balance FROM Investors WHERE investor_id = 9001 FOR UPDATE;
UPDATE Investors SET wallet_balance = wallet_balance - 10000 WHERE investor_id = 9001;
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
VALUES (9001, 9002, 10000, CURDATE());
UPDATE Loans SET amount_funded = 10000, status = 'active', funded_date = CURDATE() WHERE loan_id = 9002;
CALL generate_schedule(9002);
-- PAUSE before COMMIT.
```

**B — this call waits:**

```sql
CALL fund_loan(9002, 9002, 8000);
```

**A — finish, then inspect B's error:**

```sql
COMMIT;
```

B receives `Loan already funded.` Its wallet and the loan stay unchanged.

## Four viva lines

1. Without a locking read, both sessions can approve money using the same old balance.
2. `FOR UPDATE` lets only one session check and change that loan at a time.
3. After the first session commits, the second reads the new balance and rejects an excessive contribution.
4. `ROLLBACK` cancels every change in a failed transaction; `COMMIT` saves all successful changes together.

Do not put `CALL fund_loan` or `CALL pay_installment` inside an outer transaction: they own their transaction. The manual A blocks above make the wait visible; the procedures normally finish too quickly to demonstrate by eye. If a demo is interrupted while a manual transaction is open, run `ROLLBACK` in that session.
