USE microfinance_sdg;
SET time_zone = '+05:30';

-- Load this once, after procedures.sql and triggers_events.sql, into empty tables.
-- Dates move with the day you load it, keeping the classroom demo useful later.
START TRANSACTION;

-- Twenty borrowers live in five villages and run five types of businesses.
INSERT INTO Borrowers (borrower_id, name, village, business_type, joined_date) VALUES
(1, 'Asha Patil', 'Rampur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(2, 'Ravi Kumar', 'Rampur', 'shop', CURDATE() - INTERVAL 2 YEAR),
(3, 'Meena Devi', 'Rampur', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(4, 'Suresh Yadav', 'Rampur', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(5, 'Lakshmi Rao', 'Sundarpur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(6, 'Imran Khan', 'Sundarpur', 'shop', CURDATE() - INTERVAL 2 YEAR),
(7, 'Pooja Shah', 'Sundarpur', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(8, 'Kiran Das', 'Sundarpur', 'other', CURDATE() - INTERVAL 2 YEAR),
(9, 'Anita Joshi', 'Devgaon', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(10, 'Mohan Singh', 'Devgaon', 'farming', CURDATE() - INTERVAL 2 YEAR),
(11, 'Fatima Ali', 'Devgaon', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(12, 'Deepak Verma', 'Devgaon', 'shop', CURDATE() - INTERVAL 2 YEAR),
(13, 'Sita Nair', 'Shivapur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(14, 'Arun Reddy', 'Shivapur', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(15, 'Rekha Sen', 'Shivapur', 'other', CURDATE() - INTERVAL 2 YEAR),
(16, 'Vijay More', 'Shivapur', 'shop', CURDATE() - INTERVAL 2 YEAR),
(17, 'Sunita Kale', 'Haripur', 'tailoring', CURDATE() - INTERVAL 2 YEAR),
(18, 'Rahul Das', 'Haripur', 'farming', CURDATE() - INTERVAL 2 YEAR),
(19, 'Nisha Roy', 'Haripur', 'dairy', CURDATE() - INTERVAL 2 YEAR),
(20, 'Ganesh Mali', 'Haripur', 'other', CURDATE() - INTERVAL 2 YEAR);

-- These are starting wallets; contributions below are deducted and payouts added.
INSERT INTO Investors (investor_id, name, email, wallet_balance) VALUES
(1, 'Aarav Mehta', 'aarav@example.com', 150000),
(2, 'Diya Kapoor', 'diya@example.com', 150000),
(3, 'Ishaan Gupta', 'ishaan@example.com', 150000),
(4, 'Kavya Menon', 'kavya@example.com', 150000),
(5, 'Neel Shah', 'neel@example.com', 150000),
(6, 'Priya Iyer', 'priya@example.com', 150000),
(7, 'Rohan Sethi', 'rohan@example.com', 150000),
(8, 'Sara Thomas', 'sara@example.com', 150000),
(9, 'Varun Bansal', 'varun@example.com', 150000),
(10, 'Zoya Sheikh', 'zoya@example.com', 150000);

-- Thirty loans start pending, then receive the historical contributions below.
INSERT INTO Loans (loan_id, borrower_id, amount_requested, interest_rate, term_months, created_date) VALUES
(1, 1, 10000, 12, 12, CURDATE() - INTERVAL 10 DAY),
(2, 2, 15000, 10, 6, CURDATE() - INTERVAL 12 DAY),
(3, 3, 5000, 8, 6, CURDATE() - INTERVAL 8 DAY),
(4, 4, 20000, 12, 6, CURDATE() - INTERVAL 15 DAY),
(5, 5, 25000, 10, 6, CURDATE() - INTERVAL 20 DAY),
(6, 6, 30000, 12, 12, CURDATE() - INTERVAL 18 DAY),
(7, 7, 12000, 12, 6, CURDATE() - INTERVAL 10 DAY),
(8, 8, 18000, 10, 6, CURDATE() - INTERVAL 10 DAY),
(9, 9, 24000, 12, 6, CURDATE() - INTERVAL 4 MONTH),
(10, 10, 30000, 10, 6, CURDATE() - INTERVAL 3 MONTH),
(11, 11, 15000, 12, 6, CURDATE() - INTERVAL 5 MONTH),
(12, 12, 20000, 10, 6, CURDATE() - INTERVAL 6 MONTH),
(13, 13, 36000, 12, 6, CURDATE() - INTERVAL 4 MONTH),
(14, 14, 18000, 10, 6, CURDATE() - INTERVAL 3 MONTH),
(15, 15, 12000, 12, 6, CURDATE() - INTERVAL 5 MONTH),
(16, 16, 25000, 12, 6, CURDATE() - INTERVAL 4 MONTH),
(17, 17, 10000, 10, 6, CURDATE() - INTERVAL 3 MONTH),
(18, 18, 42000, 12, 6, CURDATE() - INTERVAL 5 MONTH),
(19, 19, 30000, 10, 6, CURDATE() - INTERVAL 4 MONTH),
(20, 20, 15000, 12, 6, CURDATE() - INTERVAL 3 MONTH),
(21, 1, 50000, 10, 6, CURDATE() - INTERVAL 20 DAY),
(22, 5, 24000, 12, 6, CURDATE() - INTERVAL 20 DAY),
(23, 10, 36000, 10, 6, CURDATE() - INTERVAL 20 DAY),
(24, 13, 18000, 12, 6, CURDATE() - INTERVAL 20 DAY),
(25, 3, 12000, 12, 6, CURDATE() - INTERVAL 9 MONTH),
(26, 7, 18000, 10, 6, CURDATE() - INTERVAL 9 MONTH),
(27, 11, 24000, 12, 6, CURDATE() - INTERVAL 9 MONTH),
(28, 17, 30000, 10, 6, CURDATE() - INTERVAL 9 MONTH),
(29, 2, 20000, 12, 6, CURDATE() - INTERVAL 8 MONTH),
(30, 6, 40000, 12, 6, CURDATE() - INTERVAL 8 MONTH);

-- Three loans are partly funded; three have no contributions yet.
INSERT INTO Investments (investor_id, loan_id, amount, investment_date) VALUES
(1, 4, 4000, CURDATE() - INTERVAL 5 DAY),
(2, 5, 5000, CURDATE() - INTERVAL 5 DAY),
(3, 6, 6000, CURDATE() - INTERVAL 5 DAY);

-- Each fully funded loan has two investors: a 60% share and a 40% share.
-- MOD cycles through five pairs of investors: (1,6), (2,7), and so on.
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
SELECT MOD(loan_id - 7, 5) + 1, loan_id, amount_requested * 0.60,
       created_date + INTERVAL 5 DAY FROM Loans WHERE loan_id >= 7;
INSERT INTO Investments (investor_id, loan_id, amount, investment_date)
SELECT MOD(loan_id - 7, 5) + 6, loan_id, amount_requested * 0.40,
       created_date + INTERVAL 5 DAY FROM Loans WHERE loan_id >= 7;

-- Derive funded totals and wallets from the investment records.
UPDATE Loans AS loan SET amount_funded =
    (SELECT COALESCE(SUM(amount), 0) FROM Investments WHERE loan_id = loan.loan_id);
UPDATE Investors AS investor SET wallet_balance = wallet_balance -
    (SELECT COALESCE(SUM(amount), 0) FROM Investments WHERE investor_id = investor.investor_id);
UPDATE Loans SET status = 'funded', funded_date = created_date + INTERVAL 5 DAY WHERE loan_id >= 7;
UPDATE Loans SET status = 'active' WHERE loan_id >= 9;

-- Generate the historical schedules inside this same transaction.
CALL generate_schedule(9);
CALL generate_schedule(10);
CALL generate_schedule(11);
CALL generate_schedule(12);
CALL generate_schedule(13);
CALL generate_schedule(14);
CALL generate_schedule(15);
CALL generate_schedule(16);
CALL generate_schedule(17);
CALL generate_schedule(18);
CALL generate_schedule(19);
CALL generate_schedule(20);
CALL generate_schedule(21);
CALL generate_schedule(22);
CALL generate_schedule(23);
CALL generate_schedule(24);
CALL generate_schedule(25);
CALL generate_schedule(26);
CALL generate_schedule(27);
CALL generate_schedule(28);
CALL generate_schedule(29);
CALL generate_schedule(30);

-- Load past, on-time payments; the trigger closes loans 25 through 28.
UPDATE Repayments
SET status = 'paid', amount_paid = amount_due, paid_date = due_date - INTERVAL 1 DAY
WHERE (loan_id BETWEEN 9 AND 20 AND installment_number = 1)
   OR loan_id BETWEEN 25 AND 28
   OR (loan_id IN (29, 30) AND installment_number = 1);

-- Include two late payments with the one-time 2% fee.
UPDATE Repayments
SET status = 'paid', penalty_amount = ROUND(amount_due * 0.02, 2),
    amount_paid = amount_due + ROUND(amount_due * 0.02, 2), paid_date = due_date + INTERVAL 5 DAY
WHERE loan_id IN (29, 30) AND installment_number = 2;
UPDATE Loans SET status = 'defaulted' WHERE loan_id IN (29, 30);

-- Backfill the first investor's historical payout for each paid installment.
INSERT INTO InvestorPayouts (repayment_id, investor_id, principal_amount, interest_amount, penalty_amount, total_amount, paid_date)
SELECT repayment_id, MOD(loan_id - 7, 5) + 1,
       ROUND(principal_due * 0.60, 2), ROUND(interest_due * 0.60, 2), ROUND(penalty_amount * 0.60, 2),
       ROUND(principal_due * 0.60, 2) + ROUND(interest_due * 0.60, 2) + ROUND(penalty_amount * 0.60, 2), paid_date
FROM Repayments WHERE status = 'paid';

-- Give the second investor exactly the remainder, including leftover paise.
INSERT INTO InvestorPayouts (repayment_id, investor_id, principal_amount, interest_amount, penalty_amount, total_amount, paid_date)
SELECT payment.repayment_id, MOD(payment.loan_id - 7, 5) + 6,
       payment.principal_due - payout.principal_amount,
       payment.interest_due - payout.interest_amount,
       payment.penalty_amount - payout.penalty_amount,
       payment.amount_paid - payout.total_amount, payment.paid_date
FROM Repayments AS payment JOIN InvestorPayouts AS payout ON payout.repayment_id = payment.repayment_id
WHERE payment.status = 'paid';
UPDATE Investors AS investor SET wallet_balance = wallet_balance +
    (SELECT COALESCE(SUM(total_amount), 0) FROM InvestorPayouts WHERE investor_id = investor.investor_id);

-- Report impact for every active and closed loan, once per loan.
INSERT INTO ImpactMetrics (loan_id, jobs_created, income_increase, hectares_farmed, sdg_goal) VALUES
(9, 2, 2500, 0, 1), (10, 3, 3200, 1.5, 8), (11, 2, 2000, 0, 1),
(12, 1, 2200, 0, 8), (13, 4, 4500, 2.0, 8), (14, 2, 1800, 0, 1),
(15, 1, 1500, 0, 1), (16, 2, 2800, 0, 8), (17, 1, 1600, 0, 1),
(18, 4, 5200, 2.5, 8), (19, 3, 3000, 0, 1), (20, 1, 1700, 0, 8),
(21, 5, 6000, 3.0, 8), (22, 2, 2800, 1.2, 1), (23, 3, 4200, 2.0, 8),
(24, 2, 2400, 1.0, 1), (25, 1, 1900, 0, 1), (26, 2, 2300, 0, 8),
(27, 3, 3100, 0, 8), (28, 2, 2600, 0, 1);

-- Classify remaining late installments and calculate repeatable credit scores.
CALL update_penalties();
CALL update_credit_scores();
COMMIT;

-- Expected loan counts: pending 6, funded 2, active 16, closed 4, defaulted 2.
SELECT status, COUNT(*) AS loan_count FROM Loans GROUP BY status;
