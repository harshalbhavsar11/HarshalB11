# Verification results

Verified on **11 October 2026** using an isolated local MySQL **8.0.46** server, Python **3.14**, mysql-connector-python **9.7.0**, pandas **3.0.6**, and Streamlit **1.65.0**.

## Passed

- All six SQL files imported successfully, including indexes, accounts, grants, triggers, and the event definition.
- Sample counts: 20 borrowers, 10 investors, 30 loans, 51 investments, 132 installments, 80 payouts, and 20 impact records. Loan statuses matched the documented 6/2/16/4/2 split.
- Starting wallet minus contributions plus actual payouts matched every investor's wallet. Total payouts equalled total repayments collected, both before and after concurrent operations.
- Interest for ₹10,000 at 12% over 12 months was ₹1,200; the schedule summed to exactly ₹11,200, including the last installment's rounding adjustment.
- Zero, negative, NULL, excessive, unfunded-wallet, missing-investor, and missing-loan requests were rejected with no wallet changes. Duplicate schedules and payments were rejected.
- Repeated penalty and credit-score updates did not apply the same fee or score change again.
- A forced schedule insertion failure rolled back the contribution, wallet debit, investment record, and status audit entry.
- A forced second-investor payout failure rolled back the first investor's payout and wallet update as well as the payment.
- Paying the final installment closed the loan and added exactly one closing audit entry.
- In two real sessions, the second funding call waited for the loan lock, then received either the ₹2,000-remaining error or “Loan already funded.” as appropriate.
- Two queued payments for different final installments both succeeded and closed the loan. Multiple contributions from one investor produced one payout per installment for that investor.
- The unsafe demo reproduced ₹16,000 funding from two stale ₹8,000 approvals; the production table's CHECK separately rejected overfunding.
- The reporting account could read views but could not read the base Investors table, update wallets, or call fund_loan.
- Streamlit AppTest rendered all six pages without application errors. Combined status/village filters returned the expected records.
- `mysqldump` and restore succeeded into a separate temporary schema. All table/view row counts, procedure/trigger/event counts, restored interest calculation, and payout totals matched.

## Scope and limits

The first cold Streamlit render exceeded a 20-second test timeout; a 60-second allowance completed successfully. The final integration run passed in full. Database tests use actual MySQL, not a SQL mock.

The nightly event's definition and penalty procedure were tested; the test did not wait until midnight or turn on the server-wide scheduler. Browser appearance was not manually inspected. Timing speedups are not claimed for this small dataset; EXPLAIN output depends on MySQL's optimizer.

Test commands and requirements are in [tests/README.md](tests/README.md). The temporary test server was separate from the user's normal MySQL service. Personal database credentials were not required or saved.
