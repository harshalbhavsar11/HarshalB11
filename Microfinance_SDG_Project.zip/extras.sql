USE microfinance_sdg;

-- InnoDB already indexes primary keys and foreign keys used for basic joins.
SHOW INDEX FROM Loans;
SHOW INDEX FROM Investments;
SHOW INDEX FROM Repayments;

-- Compare the same lookup before and after a useful two-column index.
EXPLAIN SELECT repayment_id, loan_id, due_date FROM Repayments
WHERE status = 'overdue' AND due_date < CURDATE();
CREATE INDEX index_repayments_status_due_date ON Repayments(status, due_date);
ANALYZE TABLE Repayments;
EXPLAIN SELECT repayment_id, loan_id, due_date FROM Repayments
WHERE status = 'overdue' AND due_date < CURDATE();

-- On a tiny sample MySQL may correctly prefer a full scan, even after indexing.
-- Compare possible_keys, key, type, and rows; do not claim timings from EXPLAIN.
CREATE INDEX index_investments_loan_investor ON Investments(loan_id, investor_id);
CREATE INDEX index_borrowers_village ON Borrowers(village);

-- Stop here unless you are the administrator and have edited both passwords below.
-- Replace these classroom placeholders with two passwords of your own before SOURCE.
CREATE USER 'microfinance_admin'@'localhost' IDENTIFIED BY 'REPLACE_ADMIN_PASSWORD';
CREATE USER 'microfinance_investor'@'localhost' IDENTIFIED BY 'REPLACE_INVESTOR_PASSWORD';

-- The admin manages this database, not every database on the server.
GRANT ALL PRIVILEGES ON microfinance_sdg.* TO 'microfinance_admin'@'localhost';

-- Views use their creator's permissions by default; this user cannot change money.
-- This is an aggregate classroom reporting account, not per-investor privacy isolation.
GRANT SELECT ON microfinance_sdg.overdue_loans TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.village_default_rates TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.investor_returns TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.business_repayment_performance TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.jobs_per_lakh TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.portfolio_risk TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.sdg_summary TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.dashboard_overview TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.loans_and_borrowers TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.monthly_repayments TO 'microfinance_investor'@'localhost';
GRANT SELECT ON microfinance_sdg.repayment_details TO 'microfinance_investor'@'localhost';
SHOW GRANTS FOR 'microfinance_investor'@'localhost';

-- Read the audit trail together with the borrower name.
SELECT log.log_id, log.loan_id, borrower.name, log.old_status, log.new_status, log.changed_at
FROM LoanStatusLog AS log JOIN Loans AS loan ON loan.loan_id = log.loan_id
JOIN Borrowers AS borrower ON borrower.borrower_id = loan.borrower_id
ORDER BY log.changed_at, log.log_id;

-- BACKUP: run in PowerShell or a terminal, not inside the MySQL prompt.
-- The result-file option avoids PowerShell text-encoding changes.
-- mysqldump -u root -p --single-transaction --routines --triggers --events --no-tablespaces --set-gtid-purged=OFF --databases microfinance_sdg --result-file=microfinance_backup.sql

-- RESTORE: first use a separate empty MySQL server for practice.
-- The backup includes CREATE DATABASE and USE, so do not restore it over live data.
-- mysql -u root -p --execute="SOURCE microfinance_backup.sql"

-- Account grants are not part of this database dump. Recreate only the CREATE USER
-- and GRANT section on the new server, after restoring the views and their definer.
-- Enable the event scheduler on that server if the nightly job should run there.
